(() => {
  const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase().trim();
  const destination = href => {
    try {
      const url = new URL(href, window.location.href);
      if (url.origin !== window.location.origin) return null;
      const path = decodeURI(url.pathname).replace(/\/+$/, '');
      const collectionPath = path.match(/\/collections\/[^/]+$/);
      return collectionPath ? collectionPath[0] + url.search : null;
    } catch { return null; }
  };
  const initialize = root => {
    if (root.dataset.exploreReady === 'true') return;
    root.dataset.exploreReady = 'true';
    const seen = new Set();
    document.querySelectorAll('.lx-tabs a[href], .lx-uf a[href]').forEach(link => {
      if (root.contains(link)) return;
      const key = destination(link.getAttribute('href'));
      if (key) seen.add(key);
    });
    const cards = [...root.querySelectorAll('[data-area-item]')];
    const available = cards.filter(card => {
      const key = destination(card.querySelector('a[href]')?.getAttribute('href'));
      const duplicate = key !== null && seen.has(key);
      card.hidden = duplicate;
      if (duplicate) card.dataset.areaDuplicate = 'true';
      else if (key) seen.add(key);
      return !duplicate;
    });
    root.hidden = available.length === 0;
    if (root.hidden) return;
    const search = root.querySelector('[data-area-search]');
    const input = search?.querySelector('input');
    const reset = search?.querySelector('button');
    const empty = root.querySelector('[data-area-empty]');
    if (!search || !input || !reset || !empty || available.length <= 4) return;
    search.hidden = false;
    const filter = () => {
      const query = normalize(input.value);
      let matches = 0;
      for (const card of available) {
        const show = !query || normalize(card.textContent).includes(query);
        card.hidden = !show;
        if (show) matches++;
      }
      empty.hidden = matches !== 0;
      reset.hidden = !query;
    };
    input.addEventListener('input', filter);
    input.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        input.value = '';
        filter();
      }
    });
    reset.addEventListener('click', () => {
      input.value = '';
      filter();
      input.focus();
    });
    filter();
  };
  const scan = scope => scope.querySelectorAll('[data-collection-explore]').forEach(initialize);
  scan(document);
  document.addEventListener('shopify:section:load', event => scan(event.target));
})();
