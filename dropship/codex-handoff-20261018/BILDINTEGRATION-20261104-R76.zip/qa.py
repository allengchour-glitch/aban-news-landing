#!/usr/bin/env python3
"""Bounded, read-only native-preview QA for R76. Network starts only with --run.

Reuses source-reviewed R73 GET/HEAD guard and preview readiness check. Does not
click product links, cart, checkout or forms, and never calls the Theme API.
Only local JSON reports and screenshots are written.
"""
import argparse
import asyncio
import datetime
import hashlib
import json
import re
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

BASE = Path(__file__).resolve().parent
R73 = Path('/workspace/luxestyle-review/category-polish-20261103-r73/qa')
sys.path.insert(0, str(R73))
from native_followup import guard, ready  # Reviewed; no work at import time.
from native_qa import THEME, preview_url
from playwright.async_api import async_playwright

EXPECTED_THEME = {'id': '212978598279', 'role': 'unpublished'}
PRODUCTS = {
    'vorratsdosen': {
        'key': 'spice', 'product': '15504177136001',
        'handle': 'keramik-gewurztopf-im-nordic-style-492928',
        'variant': '67789402210695', 'image': 'luxestyle-gewuerztopf-20261104-r75',
    },
    'camping-geschirr-kochsets': {
        'key': 'camping', 'product': '16656666919303',
        'handle': 'camping-kochset-3-teilig-leicht-639500',
        'variant': '67760472424839', 'image': 'luxestyle-camping-20261104-r75',
    },
    'hundewelt': {
        'key': 'dog', 'product': '16654280753543',
        'handle': 'hundennasenmatte-aus-fleece-energie-intelligen-622000',
        'variant': '67747895443847', 'image': 'luxestyle-hundematte-20261104-r75',
    },
}
CASES = [
    {'handle': handle, 'width': width, 'language': 'de', 'positive': True}
    for handle in PRODUCTS for width in (1440, 390, 320)
] + [
    {'handle': 'vorratsdosen', 'width': 390, 'language': 'fr', 'positive': True},
    {'handle': 'tier-intelligenzspielzeug', 'width': 390, 'language': 'de', 'positive': False},
    {'handle': '', 'width': 390, 'language': 'de', 'positive': False},
]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read_json(path):
    text = path.read_text()
    return json.loads(text[text.index('{'):])


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def check(row, name, passed, evidence=None):
    row['checks'].append({'name': name, 'pass': bool(passed), 'evidence': evidence})


def save(report):
    (BASE / 'QA-REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')


def local_source_check():
    """This proves local preservation; remote preservation is separately checked."""
    before = read_json(BASE / 'before/draft/templates/collection.json')
    after = read_json(BASE / 'after/templates/collection.json')
    homepage = read_json(BASE / 'before/draft/templates/index.json')
    row = {'scope': 'Local before/draft versus after, not proof of remote write', 'checks': []}
    check(row, 'only_one_new_collection_section',
          set(after['sections']) - set(before['sections']) == {'lux_product_inspiration'})
    changed = [k for k, value in before['sections'].items() if after['sections'].get(k) != value]
    check(row, 'all_existing_sections_byte_equivalent_as_json_values', not changed, changed)
    check(row, 'original_relative_section_order_preserved',
          [k for k in after['order'] if k in before['order']] == before['order'], after['order'])
    check(row, 'inspiration_after_banner_before_grid',
          after['order'].index('lux_hero') < after['order'].index('lux_product_inspiration')
          < after['order'].index('main'))
    check(row, 'homepage_not_in_change_set', not (BASE / 'after/templates/index.json').exists())
    style = '\n'.join(re.findall(r'<style[^>]*>(.*?)</style>',
                        before['sections']['lux_hero']['settings']['custom_liquid'], re.S)).strip()
    return row, before['order'], homepage['order'], digest(style)


async def inspect(page):
    return await page.evaluate(r'''() => {
      const rect = e => {const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}};
      const hero = document.querySelector('[id*="__lux_hero"]');
      const banner = hero?.querySelector('.lx-hero');
      const card = document.querySelector('.lx-inspiration');
      const image = card?.querySelector('img');
      const link = card?.querySelector('.lx-inspiration__link');
      const grid = document.querySelector('results-list.product-grid-container');
      const result = {
        location:location.href, htmlLanguage:document.documentElement.lang,
        documentWidth:document.documentElement.scrollWidth, viewportWidth:innerWidth,
        cardCount:document.querySelectorAll('.lx-inspiration').length,
        h1:[...document.querySelectorAll('main h1')].map(e=>e.textContent.trim()),
        sectionOrder:[...document.querySelectorAll('main > .shopify-section')].map(e=>e.id.split('__').pop()),
        bannerCount:document.querySelectorAll('.lx-hero').length,
        bannerHeading:[...(banner?.querySelectorAll('h1')||[])].map(e=>e.textContent.trim()),
        bannerImages:[...(banner?.querySelectorAll('img')||[])].map(e=>e.getAttribute('src')),
        bannerCss:[...(hero?.querySelectorAll('style')||[])].map(e=>e.textContent).join('\n').trim(),
        gridCount:document.querySelectorAll('results-list.product-grid-container').length,
        productCards:grid?.querySelectorAll('.product-grid__item[data-product-id]').length||0,
        hasSearch:document.querySelectorAll('input[name="q"]').length>0,
      };
      if(card) result.card={
        box:rect(card), product:card.dataset.inspirationProduct,
        heading:card.querySelector('h2')?.textContent.trim(),
        text:card.textContent.replace(/\s+/g,' ').trim(),
        image:image?{box:rect(image), complete:image.complete,
          naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight,
          widthAttribute:image.getAttribute('width'),heightAttribute:image.getAttribute('height'),
          src:image.currentSrc||image.src,srcset:image.getAttribute('srcset'),
          sizes:image.getAttribute('sizes'),alt:image.alt,objectFit:getComputedStyle(image).objectFit}:null,
        link:link?{box:rect(link),href:link.href,text:link.textContent.trim(),label:link.getAttribute('aria-label')}:null,
        afterBanner:!!banner && !!(banner.compareDocumentPosition(card)&Node.DOCUMENT_POSITION_FOLLOWING),
        beforeGrid:!!grid && !!(card.compareDocumentPosition(grid)&Node.DOCUMENT_POSITION_FOLLOWING),
      };
      return result;
    }''')


async def main():
    report = {'at': now(), 'theme': EXPECTED_THEME, 'scope':
              '12 native preview views only; first collection page; no product clicks, cart, checkout, POST, Theme API or tracking',
              'sourceFiles': {p.name: digest(p.read_text()) for p in (R73/'native_followup.py', R73/'native_qa.py')},
              'views': [], 'screenshots': []}
    source, original_order, homepage_order, hero_css_hash = local_source_check()
    report['localSource'] = source
    if THEME != EXPECTED_THEME['id'] or any(not c['pass'] for c in source['checks']):
        report['unknown'] = 'Local source invariants failed; browser QA not started.'
        save(report)
        return 2
    output = BASE / 'screenshots'
    output.mkdir(exist_ok=True)
    comparison = {}
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path='/usr/bin/chromium', chromium_sandbox=True,
                                           args=['--disable-dev-shm-usage'])
        context = await browser.new_context(viewport={'width':390,'height':1000}, locale='de-CH',
                                            reduced_motion='reduce', service_workers='block')
        # Reuse the R73 request guard. Additional known tracking GET endpoints are denied.
        async def bounded_guard(route):
            url = route.request.url.lower()
            if any(x in url for x in ('/api/collect', '/wpm', 'googleadservices.com',
                                     'doubleclick.net', 'analytics.shopify.com', 'shopifysvc.com/collect')):
                await route.abort()
            else:
                await guard(route)
        await context.route('**/*', bounded_guard)
        page = await context.new_page()
        for case in CASES:
            row = dict(case, at=now(), checks=[], consoleErrors=[])
            slug = case['handle'] or 'homepage'
            prefix = '/fr' if case['language'] == 'fr' else ''
            path = prefix + ('/collections/' + case['handle'] if case['handle'] else '/')
            try:
                await page.set_viewport_size({'width': case['width'], 'height': 1000})
                errors = []
                listener = lambda error: errors.append(str(error)[:300])
                page.on('pageerror', listener)
                response = await page.goto(preview_url(path), wait_until='domcontentloaded', timeout=45000)
                row['httpStatus'] = response.status if response else None
                check(row, 'http200', row['httpStatus'] == 200, row['httpStatus'])
                try:
                    row['theme'] = await ready(page)
                except Exception as error:
                    raise RuntimeError('Preview identity unverified; stop all dependent views: ' + str(error)) from error
                check(row, 'native_unpublished_identity', row['theme'] == EXPECTED_THEME, row['theme'])
                if case['positive']:
                    card = page.locator('.lx-inspiration')
                    await card.wait_for(state='visible', timeout=12000)
                    await card.scroll_into_view_if_needed(timeout=5000)
                    await page.wait_for_function("""() => {
                        const i=document.querySelector('.lx-inspiration img');
                        return i && i.complete && i.naturalWidth>0;
                    }""", timeout=15000)
                data = await inspect(page)
                row['dom'] = data
                check(row, 'no_horizontal_overflow', data['documentWidth'] <= data['viewportWidth'] + 1,
                      {'document': data['documentWidth'], 'viewport': data['viewportWidth']})
                check(row, 'global_search_preserved', data['hasSearch'])
                if case['handle']:
                    check(row, 'existing_collection_sections_in_order',
                          [x for x in data['sectionOrder'] if x in original_order] == original_order,
                          data['sectionOrder'])
                    check(row, 'original_banner_present', data['bannerCount'] == 1)
                    check(row, 'banner_css_matches_fresh_original', digest(data['bannerCss']) == hero_css_hash)
                    check(row, 'single_nonempty_banner_h1', len(data['bannerHeading']) == 1 and bool(data['bannerHeading'][0]))
                    check(row, 'original_product_grid_present', data['gridCount'] == 1 and data['productCards'] > 0,
                          {'grids':data['gridCount'],'firstPageCards':data['productCards']})
                    baseline_key = (case['handle'], case['language'])
                    identity = {'h1':data['bannerHeading'],'images':data['bannerImages']}
                    if baseline_key in comparison:
                        check(row, 'banner_content_consistent_across_viewports', identity == comparison[baseline_key])
                    else:
                        comparison[baseline_key] = identity
                else:
                    check(row, 'R72_homepage_section_order_preserved',
                          [x for x in data['sectionOrder'] if x in homepage_order] == homepage_order,
                          data['sectionOrder'])
                check(row, 'exactly_one_card_or_none_as_scoped', data['cardCount'] == int(case['positive']), data['cardCount'])
                if case['positive']:
                    expected = PRODUCTS[case['handle']]
                    card = data['card']; image = card['image']; link = card['link']
                    locale = read_json(BASE / ('after/locales/fr.json' if case['language']=='fr' else 'after/locales/de.json'))
                    check(row, 'correct_product_identity', card['product'] == expected['product'], card['product'])
                    check(row, 'correct_translated_heading', card['heading'] == locale['luxe_inspiration'][expected['key']]['title'], card['heading'])
                    check(row, 'no_missing_translation', 'translation missing' not in card['text'].lower())
                    check(row, 'small_card_between_existing_banner_and_grid', card['afterBanner'] and card['beforeGrid'])
                    check(row, 'card_within_viewport', card['box']['x'] >= -1 and card['box']['x'] + card['box']['width'] <= case['width']+1)
                    check(row, 'image_loaded_and_correct_asset', image['complete'] and image['naturalWidth'] > 0 and expected['image'] in image['src'], image['src'])
                    check(row, 'responsive_image_markup', bool(image['srcset']) and bool(image['sizes'])
                          and int(image['widthAttribute'] or 0)>0 and int(image['heightAttribute'] or 0)>0)
                    natural_ratio = image['naturalWidth'] / image['naturalHeight']
                    displayed_ratio = image['box']['width'] / image['box']['height']
                    check(row, 'image_three_by_two_without_crop', abs(natural_ratio-1.5)<0.005
                          and abs(displayed_ratio-1.5)<0.015 and image['objectFit']=='contain',
                          {'naturalRatio':natural_ratio,'displayedRatio':displayed_ratio,'objectFit':image['objectFit']})
                    check(row, 'useful_image_alt', len(image['alt'].strip())>10, image['alt'])
                    url = urlsplit(link['href'])
                    expected_path = prefix + '/products/' + expected['handle']
                    check(row, 'exact_product_variant_and_localized_path', url.netloc=='luxestyle.ch'
                          and url.path==expected_path and parse_qs(url.query).get('variant')==[expected['variant']], link['href'])
                    check(row, 'CTA_touch_target_at_least_44px', link['box']['height'] >= 43.9 and link['box']['width'] >= 43.9, link['box'])
                    check(row, 'CTA_accessible_name', bool(link['label']) and bool(link['text']))
                    name = f'{slug}-{case["language"]}-{case["width"]}'
                    await page.locator('.lx-inspiration').screenshot(path=str(output/(name+'-card.png')))
                    report['screenshots'].append('screenshots/'+name+'-card.png')
                    if case['width'] in (390,320):
                        await page.evaluate("""() => {const e=document.querySelector('.lx-inspiration');
                          window.scrollTo(0,Math.max(0,e.getBoundingClientRect().top+scrollY-130));} """)
                        await page.screenshot(path=str(output/(name+'-context.png')))
                        report['screenshots'].append('screenshots/'+name+'-context.png')
                else:
                    await page.screenshot(path=str(output/(slug+'-de-390-control.png')))
                    report['screenshots'].append('screenshots/'+slug+'-de-390-control.png')
                row['consoleErrors'] = errors
                page.remove_listener('pageerror', listener)
            except Exception as error:
                row['unknown'] = type(error).__name__ + ': ' + str(error)[:700]
                if 'Preview identity unverified' in str(error):
                    report['views'].append(row)
                    report['stopped'] = 'Identity failure; remaining cases intentionally not visited.'
                    save(report)
                    break
            report['views'].append(row)
            save(report)
        await context.close()
        await browser.close()
    checks = [c for row in report['views'] for c in row['checks']]
    report['finishedAt'] = now()
    report['result'] = {
        'passed':sum(c['pass'] for c in checks), 'total':len(checks),
        'visited':len(report['views']), 'planned':len(CASES),
        'failed':[{'handle':r['handle'],'width':r['width'],'language':r['language'],**c}
                  for r in report['views'] for c in r['checks'] if not c['pass']],
        'unknown':[{'handle':r['handle'],'width':r['width'],'language':r['language'],'error':r['unknown']}
                   for r in report['views'] if 'unknown' in r],
    }
    save(report)
    print(json.dumps(report['result'], ensure_ascii=False, indent=2))
    return int(bool(report['result']['failed'] or report['result']['unknown']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='Explicitly start the bounded read-only browser QA.')
    args = parser.parse_args()
    if not args.run:
        parser.error('Browser QA is not started automatically. After authorisation, invoke with --run.')
    raise SystemExit(asyncio.run(main()))
