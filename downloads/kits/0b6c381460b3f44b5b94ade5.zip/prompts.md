**Important Note:** AI-generated content should always be reviewed and verified by a human expert for accuracy, medical correctness, and patient safety before use.

Here are 6 proven, concrete copy-paste AI prompts for Ärzte:

*   "Generate a draft patient information leaflet for [medical condition, e.g., Type 2 Diabetes] that includes common symptoms, diagnostic procedures, treatment options (medication, lifestyle changes, surgery if applicable), and potential complications. The language should be clear, concise, and understandable for a general audience, avoiding overly technical jargon. Focus on empowering patients with knowledge."

*   "Summarize the key findings and clinical implications from the following research paper abstract: '[Paste abstract text here]'. Identify the study's strengths, limitations, and suggest two potential areas for future research based on these findings."

*   "Draft a concise, professional email to a colleague, Dr. [Colleague's Last Name], requesting a consultation regarding a patient presenting with [patient's chief complaint, e.g., persistent unexplained fatigue and weight loss]. Briefly outline the patient's relevant medical history and current diagnostic challenges. Suggest a suitable time for a brief discussion."

*   "Create a list of five evidence-based recommendations for patients recovering from [specific surgery or procedure, e.g., total knee replacement]. Include advice on pain management, physical activity progression, wound care, and signs of potential complications that warrant immediate medical attention. Format as bullet points."

*   "Formulate a script for a brief patient conversation explaining the benefits and risks of [specific medication, e.g., a new anticoagulant] for a patient with [patient's condition, e.g., atrial fibrillation]. Include common side effects, important drug interactions to avoid, and when to contact the clinic. Aim for a empathetic and informative tone."

*   "Develop a differential diagnosis list for a patient presenting with [patient's primary symptom, e.g., acute onset severe abdominal pain in the right lower quadrant]. For each potential diagnosis, briefly list one or two key differentiating clinical features or diagnostic tests that would help confirm or rule it out."
