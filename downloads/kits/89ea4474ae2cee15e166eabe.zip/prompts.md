**Remember to always review and refine AI-generated content to ensure accuracy, brand voice, and suitability for your specific needs.**

* "Write a compelling, SEO-optimized meta description for our hotel, [Hotel Name], located in [City, State]. Focus on our key selling points: [2-3 unique selling points, e.g., 'luxury amenities,' 'historic charm,' 'beachfront access'], and encourage direct bookings. Max 160 characters."

* "Generate 5 engaging social media post ideas for our hotel, [Hotel Name], promoting a special offer: [Offer details, e.g., '20% off weekend stays,' 'complimentary breakfast for two']. Include relevant hashtags for each post. Target audience: [e.g., 'families,' 'couples,' 'business travelers']."

* "Draft a personalized email subject line and opening paragraph for a guest who recently stayed at [Hotel Name] and left a positive review on [Review Platform, e.g., TripAdvisor]. The email should thank them for their feedback and subtly encourage a return visit. Guest's name: [Guest Name]."

* "Create a concise, benefit-driven bullet-point list of 4-5 reasons why a traveler should choose [Hotel Name] over competitors in [City, State]. Focus on tangible advantages like [e.g., 'spacious rooms,' 'award-winning restaurant,' 'proximity to attractions']."

* "Write a short, engaging description for our hotel's 'About Us' page on our website. Highlight our unique story or philosophy, our commitment to guest experience, and what makes [Hotel Name] special. Aim for 100-150 words."

* "Generate 3 compelling headlines for a Google Ads campaign promoting [Hotel Name]'s [specific feature or offer, e.g., 'pet-friendly rooms,' 'conference facilities,' 'winter getaway package']. Each headline should be under 30 characters and include a strong call to action."
