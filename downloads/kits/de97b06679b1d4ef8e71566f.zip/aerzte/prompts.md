**Wichtiger Hinweis:** Die von der KI generierten Inhalte sind als Vorschläge zu verstehen und müssen stets kritisch geprüft und an die spezifischen Bedürfnisse und den Kontext angepasst werden. Sie ersetzen keine professionelle medizinische Beratung oder Entscheidungsfindung.

Hier sind 6 erprobte, konkrete KI-Prompts für Ärzte (DACH):

*   "Ich benötige einen Entwurf für einen Patienteninformationsflyer zum Thema '[Krankheitsbild, z.B. Diabetes Typ 2]'. Der Flyer soll die Ursachen, Symptome, Diagnose und Behandlungsmöglichkeiten verständlich erklären. Bitte verwende eine leicht verständliche Sprache und vermeide medizinischen Fachjargon, wo immer möglich. Füge auch Hinweise zu Lebensstiländerungen und Prävention hinzu. Die Zielgruppe sind Patienten im Alter von [Altersgruppe, z.B. 40-70 Jahre]."

*   "Formuliere eine E-Mail an einen Kollegen, in der ich um eine Zweitmeinung bezüglich eines komplexen Falls von '[Patientenfall, z.B. therapieresistenter Hypertonie]' bitte. Beschreibe kurz die Anamnese, bisherigen Behandlungen und die aktuelle Problemstellung. Frage nach seiner Einschätzung und möglichen weiteren diagnostischen oder therapeutischen Schritten. Füge an, dass ich ihm die vollständigen Unterlagen gerne zukommen lasse."

*   "Erstelle eine Liste von möglichen Differentialdiagnosen für einen Patienten mit folgenden Symptomen: '[Liste der Symptome, z.B. chronische Müdigkeit, Gelenkschmerzen, unerklärlicher Gewichtsverlust]'. Berücksichtige dabei sowohl häufige als auch seltenere Erkrankungen. Gib auch an, welche diagnostischen Schritte zur Abklärung der einzelnen Differentialdiagnosen sinnvoll wären."

*   "Ich möchte einen kurzen Artikel für unsere Praxis-Website zum Thema '[Präventionsthema, z.B. Grippeschutzimpfung]' verfassen. Bitte formuliere die wichtigsten Argumente für die Impfung, kläre über mögliche Nebenwirkungen auf und gib praktische Tipps, wo und wann man sich impfen lassen kann. Der Ton soll informativ und vertrauenswürdig sein."

*   "Entwickle eine Checkliste für die Anamnese bei Verdacht auf '[Krankheitsbild, z.B. Burnout-Syndrom]'. Die Checkliste soll relevante Fragen zu Arbeitsbelastung, Stressfaktoren, Schlafqualität, emotionalem Zustand und körperlichen Symptomen enthalten. Füge auch Fragen zu Bewältigungsstrategien und sozialen Ressourcen hinzu."

*   "Bitte fassen Sie die wichtigsten Erkenntnisse aus dem aktuellen Leitlinien-Update zu '[Medizinisches Thema, z.B. Behandlung von Asthma bronchiale bei Erwachsenen]' prägnant zusammen. Konzentrieren Sie sich auf Änderungen in der Diagnostik, Therapieempfehlungen und neue Medikamente. Listen Sie die Quellen der Leitlinie auf."
