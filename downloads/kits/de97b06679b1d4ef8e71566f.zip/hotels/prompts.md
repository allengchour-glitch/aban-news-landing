**Hinweis:** Die Ergebnisse von KI-Prompts sollten immer sorgfältig geprüft und bei Bedarf angepasst werden, um Genauigkeit und Relevanz zu gewährleisten.

Hier sind 6 erprobte, konkrete KI-Prompts für Hotels (DACH) in der Du-Form:

*   "Du bist ein erfahrener Hotelmanager. Schreibe einen freundlichen, aber professionellen Willkommensbrief für unsere Gäste, die zum ersten Mal in unserem [Hotelname] übernachten. Erwähne kurz die Highlights unseres Hotels wie [Besonderheit 1, z.B. unser preisgekröntes Restaurant] und [Besonderheit 2, z.B. unser Wellnessbereich]. Füge einen Satz hinzu, der unsere Gäste ermutigt, sich bei Fragen an die Rezeption zu wenden."

*   "Du bist ein Social Media Manager für ein Hotel. Erstelle 3-5 kurze, ansprechende Instagram-Post-Ideen für unser [Hotelname], die unsere [Zielgruppe, z.B. Familien mit Kindern] ansprechen. Jede Idee sollte einen Vorschlag für ein Bild/Video und relevante Hashtags enthalten. Konzentriere dich auf [Jahreszeit/Event, z.B. den Sommerurlaub] und unsere [Lage, z.B. idyllische Berglandschaft]."

*   "Du bist ein Texter für Hotelmarketing. Formuliere eine überzeugende E-Mail für ehemalige Gäste, die wir anlässlich ihres [Jahrestag des letzten Aufenthalts] versenden möchten. Biete einen exklusiven Rabatt von [Prozentsatz, z.B. 15%] auf ihre nächste Buchung an und erwähne eine neue Attraktion/Dienstleistung in unserem [Hotelname] wie [Neuerung, z.B. unsere renovierte Bar] oder [Neuerung, z.B. unser neues E-Bike-Verleihangebot]."

*   "Du bist ein Concierge. Beantworte die häufig gestellte Frage 'Was kann man in der Umgebung von [Hotelname] unternehmen?' Gib 3-4 konkrete Empfehlungen für Aktivitäten oder Sehenswürdigkeiten in [Stadt/Region], die für unsere Gäste interessant sein könnten. Füge jeweils eine kurze Beschreibung und einen Hinweis zur Erreichbarkeit hinzu (z.B. 'nur 10 Minuten zu Fuß')."

*   "Du bist ein Hotel-Webdesigner. Schreibe einen kurzen, prägnanten Text für die 'Über uns'-Seite unseres [Hotelname]. Beschreibe unsere Philosophie, unsere Geschichte (kurz) und was uns von anderen Hotels in [Stadt/Region] unterscheidet. Betone dabei unsere [Alleinstellungsmerkmal, z.B. unsere familiäre Atmosphäre] und unser Engagement für [Wert, z.B. Nachhaltigkeit]."

*   "Du bist ein Kundenservice-Mitarbeiter. Formuliere eine höfliche und lösungsorientierte Antwort auf eine Online-Bewertung, in der ein Gast die [spezifische Beschwerde, z.B. die Lautstärke im Zimmer] bemängelt. Entschuldige dich für die Unannehmlichkeiten, zeige Verständnis und beschreibe kurz, welche Maßnahmen wir ergreifen, um solche Probleme in Zukunft zu vermeiden oder zu beheben. Lade den Gast ein, uns direkt zu kontaktieren, um die Angelegenheit persönlich zu besprechen."
