Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Garten- und Landschaftsbau (DACH), die du direkt verwenden kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen.

---

**Hinweis:** Die Ergebnisse der KI sind Vorschläge und müssen immer auf ihre Richtigkeit und Anwendbarkeit geprüft werden.

*   "Entwickle 5 kreative und nachhaltige Gestaltungskonzepte für einen [Gartentyp, z.B. Reihenhausgarten, Dachterrasse, Vorgarten] in [Region, z.B. Süddeutschland, Alpenraum, Stadtgebiet]. Berücksichtige dabei [Kundenwunsch, z.B. pflegeleicht, kinderfreundlich, insektenfreundlich] und schlage konkrete Pflanzen- und Materialvorschläge vor, die in dieser Region gut gedeihen und verfügbar sind."

*   "Erstelle einen detaillierten Projektplan für die Umgestaltung eines [Bereich, z.B. 200 qm großen Gartens, öffentlichen Parks, Firmengeländes]. Der Plan soll folgende Phasen umfassen: [Planungsphase, Ausführungsphase, Pflegephase]. Nenne konkrete Arbeitsschritte, benötigte Maschinen und Materialien sowie realistische Zeitrahmen für jede Phase. Berücksichtige dabei die typischen Herausforderungen im [Klima/Bodenart, z.B. alpinen Klima, lehmigen Boden]."

*   "Schreibe 3 überzeugende Social Media Posts (für Instagram, Facebook, LinkedIn) zur Bewerbung unseres Angebots für [Dienstleistung, z.B. Teichbau, Bewässerungssysteme, Baumpflege]. Jeder Post soll einen klaren Call-to-Action enthalten und auf die spezifischen Vorteile für unsere Kunden in [Zielgruppe, z.B. Privatkunden, Gemeinden, Unternehmen] eingehen. Verwende eine ansprechende Sprache und schlage relevante Hashtags vor."

*   "Formuliere eine E-Mail-Vorlage für die Erstkontaktaufnahme mit einem potenziellen Neukunden, der sich für [Dienstleistung, z.B. Gartenneuanlage, Terrassengestaltung] interessiert. Die E-Mail soll professionell, freundlich und informativ sein, die nächsten Schritte klar aufzeigen (z.B. Termin für Erstgespräch) und unser Fachwissen im Bereich [Spezialisierung, z.B. naturnahe Gärten, moderne Gartengestaltung] hervorheben."

*   "Erstelle eine Liste von 10 häufig gestellten Fragen (FAQs) zu unserem Service im Bereich [Dienstleistung, z.B. Rollrasenverlegung, Pflasterarbeiten, Gartenpflege-Abo]. Gib zu jeder Frage eine prägnante und hilfreiche Antwort. Die FAQs sollen darauf abzielen, potenzielle Kunden umfassend zu informieren und eventuelle Bedenken auszuräumen."

*   "Entwickle eine Checkliste für die jährliche Pflege eines [Gartentyp, z.B. Obstgartens, Steingartens, Ziergartens] in [Jahreszeit, z.B. Frühling, Herbst]. Die Checkliste soll konkrete Aufgaben wie [Beispielaufgaben, z.B. Baumschnitt, Düngung, Unkrautentfernung] enthalten und Hinweise zu den besten Zeitpunkten und Methoden geben. Füge auch Tipps zur Erkennung häufiger Schädlinge oder Krankheiten hinzu."
