**Wichtiger Hinweis:** Die von der KI generierten Inhalte sind stets auf Richtigkeit, Relevanz und Angemessenheit zu prüfen und gegebenenfalls anzupassen.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Kfz-Werkstätten (DACH):

*   "Du bist ein erfahrener Kfz-Meister und schreibst einen kurzen, informativen Blogbeitrag für unsere Kunden. Thema: 'Woran erkenne ich, dass meine Bremsen gewartet werden müssen?' Erkläre die wichtigsten Anzeichen und warum eine frühzeitige Wartung wichtig ist. Verwende eine verständliche Sprache und vermeide Fachjargon. Füge am Ende einen Call-to-Action ein, der auf unsere Werkstatt verweist."

*   "Erstelle 3 kurze Social Media Posts (für Facebook/Instagram) zur Erinnerung an den bevorstehenden Winterreifenwechsel. Jeder Post sollte einen anderen Fokus haben (z.B. Sicherheit, gesetzliche Vorschriften, Komfort). Verwende Emojis und Hashtags, die für Kfz-Werkstätten relevant sind. Der Ton soll freundlich und serviceorientiert sein. Füge einen Link zur Online-Terminbuchung ein."

*   "Formuliere eine E-Mail an unsere Bestandskunden, die seit [Anzahl] Monaten keinen Service mehr bei uns hatten. Erinnere sie freundlich an die Wichtigkeit regelmäßiger Wartung und biete einen [spezifischen Anreiz, z.B. kostenlosen Check-up bei Buchung eines Services] an. Der Betreff sollte neugierig machen. Füge unsere Kontaktdaten und einen Link zur Terminbuchung ein."

*   "Ich brauche einen kurzen Text für unsere Website im Bereich 'Über uns'. Beschreibe unsere Philosophie als Kfz-Werkstatt. Betone unsere Werte wie [zwei bis drei Werte, z.B. Ehrlichkeit, Kompetenz, Kundenzufriedenheit] und unsere [Anzahl] Jahre Erfahrung. Erkläre, was uns von anderen Werkstätten unterscheidet. Der Text sollte Vertrauen schaffen und unsere Professionalität unterstreichen."

*   "Entwickle 5 Fragen für eine Kundenumfrage, die wir nach einem Werkstattbesuch per E-Mail versenden möchten. Die Fragen sollen uns helfen, unseren Service zu verbessern. Beispiele für Bereiche: Freundlichkeit des Personals, Qualität der Arbeit, Wartezeiten, Preis-Leistungs-Verhältnis. Füge eine offene Frage für allgemeines Feedback hinzu."

*   "Schreibe einen kurzen, prägnanten Text für eine Google Ads Anzeige. Das Ziel ist es, Kunden für eine [spezifische Dienstleistung, z.B. Klimaanlagen-Check] zu gewinnen. Der Text sollte die Vorteile der Dienstleistung hervorheben, ein Problem des Kunden ansprechen und einen klaren Call-to-Action enthalten. Verwende Keywords wie '[Keyword 1], [Keyword 2]'."
