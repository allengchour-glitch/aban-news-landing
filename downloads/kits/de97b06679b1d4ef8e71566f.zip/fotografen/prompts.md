# Erprobte KI-Prompts für Fotografen

> Kopieren, eckige Klammern ersetzen, Ergebnis IMMER selbst prüfen. KI liefert Entwürfe, keine Gewähr.

1. **Angebot/Anschreiben:** „Formuliere ein freundliches, klares Angebot für [Leistung] an [Kunde].
   Stichpunkte: [...]. Ton: sachlich, kurz. Keine erfundenen Preise — die trage ich selbst ein."
2. **E-Mail-Antwort:** „Antworte höflich und knapp auf diese Nachricht: [Text einfügen]. Ziel: [...]."
3. **Bewertung beantworten:** „Schreibe eine ruhige, professionelle Antwort auf diese Online-Bewertung:
   [Text]. Kein Streit, lösungsorientiert, max. 4 Sätze."
4. **Text zusammenfassen:** „Fasse diesen Text in 5 Stichpunkten zusammen und nenne offene Fragen: [Text]."
5. **Social-Post:** „Schreibe einen kurzen, ehrlichen Post (max. 80 Wörter) über [Thema] für [Zielgruppe].
   Kein Hype, ein konkreter Tipp."
