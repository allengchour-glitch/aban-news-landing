**Wichtiger Hinweis:** KI-generierte Inhalte sind immer zu prüfen und gegebenenfalls anzupassen. Sie dienen als Ausgangspunkt und Inspiration, nicht als fertige Lösung.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Fotografen (DACH):

*   "Erstelle 5 Social Media Post-Ideen für meine Hochzeitsfotografie, die Paare in der DACH-Region ansprechen. Konzentriere dich auf emotionale Momente und den Wert meiner professionellen Begleitung. Verwende Emojis und eine lockere, aber respektvolle Ansprache."
*   "Formuliere eine kurze E-Mail-Antwort an einen potenziellen Kunden, der nach meinen Preisen für ein Familien-Shooting gefragt hat. Erkläre kurz meine Pakete (z.B. 'Basic', 'Premium', 'Deluxe') und biete ein unverbindliches Kennenlerngespräch an, um die genauen Bedürfnisse zu besprechen. Der Ton soll freundlich und professionell sein."
*   "Schreibe 3 verschiedene Instagram-Bildunterschriften für dieses Foto: [Beschreibung des Fotos, z.B. 'Porträt einer Frau im Herbstwald, warmes Licht, nachdenklicher Blick']. Eine soll inspirierend sein, eine den Fokus auf die Lichtstimmung legen und eine einen Call-to-Action enthalten, z.B. für ein eigenes Shooting."
*   "Entwickle eine kurze Blog-Idee für meine Website mit dem Titel '5 Tipps für unvergessliche [Art des Shootings, z.B. Babybauchfotos]'. Liste die 5 Tipps stichpunktartig auf und gib für jeden Tipp eine kurze Erklärung, warum er wichtig ist."
*   "Formuliere eine kurze, überzeugende 'Über mich'-Seite für meine Website. Ich bin [Dein Name], spezialisiert auf [Deine Spezialisierung, z.B. authentische Business-Porträts], und mein Ziel ist es, [Dein Ziel, z.B. die Persönlichkeit meiner Kunden sichtbar zu machen]. Erwähne kurz, was dich an der Fotografie begeistert."
*   "Erstelle 3 verschiedene Betreffzeilen für einen Newsletter, der meine aktuellen Angebote für [Art des Shootings, z.B. Weihnachtsminishootings] bewirbt. Eine soll neugierig machen, eine den Vorteil hervorheben und eine direkt zum Angebot führen."
