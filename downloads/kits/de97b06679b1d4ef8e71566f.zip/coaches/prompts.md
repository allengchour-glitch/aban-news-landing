Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Coaches im DACH-Raum, in Du-Form und mit dem Hinweis zur Prüfung der Ergebnisse:

**Wichtiger Hinweis: Die Ergebnisse der KI sind Vorschläge und müssen stets kritisch geprüft, angepasst und an deine individuelle Situation und Expertise als Coach angepasst werden.**

* "Analysiere meine Zielgruppe '[Deine Zielgruppe, z.B. 'selbstständige Frauen zwischen 30 und 45 Jahren, die berufliche Neuorientierung suchen']' und identifiziere die Top 3 ihrer größten Herausforderungen im Bereich '[Dein Coaching-Thema, z.B. 'Work-Life-Balance']'. Gib mir pro Herausforderung jeweils 3 konkrete Schmerzpunkte an, die ich in meiner Kommunikation aufgreifen kann."

* "Ich möchte einen Blogbeitrag zum Thema '[Dein Blogbeitragsthema, z.B. 'Umgang mit Prokrastination']' schreiben. Erstelle mir eine Gliederung mit 5-7 Abschnitten, die sowohl informative Inhalte als auch praktische Übungen für meine Klienten enthält. Füge am Ende einen Call-to-Action ein, der auf mein Coaching-Angebot '[Dein Coaching-Angebot, z.B. '1:1-Coaching für Produktivität']' verweist."

* "Entwickle 5 inspirierende Social-Media-Posts (Instagram/LinkedIn) für Coaches zum Thema '[Dein Coaching-Thema, z.B. 'Selbstvertrauen stärken']'. Jeder Post soll eine Frage an die Community enthalten, die zur Interaktion anregt, und einen relevanten Hashtag. Achte auf einen motivierenden und authentischen Ton."

* "Ich habe ein kostenloses Webinar zum Thema '[Dein Webinar-Thema, z.B. 'Stressmanagement für Führungskräfte']' geplant. Formuliere mir 3 verschiedene E-Mail-Betreffzeilen, die neugierig machen und eine hohe Öffnungsrate versprechen. Gib mir außerdem 3 bullet points für den E-Mail-Text, die den Nutzen des Webinars klar hervorheben."

* "Ich möchte ein neues Coaching-Programm zum Thema '[Dein neues Programm-Thema, z.B. 'Karriere-Booster für Young Professionals']' entwickeln. Brainstorme 10 mögliche Modul-Titel, die sowohl ansprechend als auch aussagekräftig sind und die Kerninhalte des Programms widerspiegeln. Füge pro Modul einen kurzen Satz hinzu, was die Teilnehmer lernen werden."

* "Formuliere 3 überzeugende Testimonials für mein Coaching-Angebot '[Dein Coaching-Angebot, z.B. 'Business-Coaching für Gründer']'. Die Testimonials sollen unterschiedliche Aspekte meines Coachings hervorheben (z.B. 'Klarheit', 'Erfolgssteigerung', 'persönliche Entwicklung') und authentisch klingen. Verwende dabei keine erfundenen Namen, sondern generische Beschreibungen wie 'Ein zufriedener Klient'."
