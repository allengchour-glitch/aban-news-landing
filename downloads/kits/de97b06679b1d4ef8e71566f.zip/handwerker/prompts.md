**Wichtiger Hinweis:** Die Ergebnisse der KI müssen immer sorgfältig geprüft und an deine spezifischen Bedürfnisse angepasst werden. KI kann ein großartiges Werkzeug sein, ersetzt aber nicht dein Fachwissen und deine Erfahrung.

Hier sind 6 erprobte, konkrete KI-Prompts für Handwerker (DACH):

*   "Ich brauche 5 überzeugende Social Media Post-Ideen für [dein Handwerk, z.B. Zimmerei], die potenzielle Kunden in [deine Region, z.B. Oberbayern] ansprechen. Die Posts sollen den Mehrwert unserer Arbeit hervorheben und eine klare Handlungsaufforderung enthalten. Vermeide Fachjargon und sei kreativ."

*   "Schreibe einen kurzen, prägnanten Text für unsere 'Über uns'-Seite auf der Website. Beschreibe, wofür unser [dein Handwerk] steht, unsere Werte und unsere langjährige Erfahrung. Der Ton soll vertrauenswürdig und professionell sein, aber auch persönlich wirken."

*   "Erstelle eine Liste mit 10 häufig gestellten Fragen (FAQs) zu [dein Handwerk, z.B. Dachsanierungen], die wir auf unserer Website beantworten können. Formuliere die Fragen aus Kundensicht und gib jeweils eine kurze, verständliche Antwort, die unsere Expertise unterstreicht."

*   "Formuliere eine E-Mail-Vorlage für die Nachfassaktion nach einem Erstkontakt mit einem potenziellen Kunden. Die E-Mail soll freundlich, aber bestimmt sein, den Dank für das Interesse ausdrücken und die nächsten Schritte klar kommunizieren. Füge einen Platzhalter für [individuelle Details] ein."

*   "Ich benötige 3 verschiedene Entwürfe für einen kurzen Slogan für unser [dein Handwerk, z.B. Sanitärbetrieb]. Die Slogans sollen unsere Zuverlässigkeit, Qualität und Kundennähe betonen und leicht merkbar sein. Sie dürfen nicht länger als 8 Wörter sein."

*   "Schreibe einen kurzen Blogbeitrag (ca. 300 Wörter) zum Thema '[aktuelles Thema in deinem Handwerk, z.B. Energieeffizienz bei Fenstern]'. Erkläre die Vorteile für den Kunden und wie unser [dein Handwerk] dabei unterstützen kann. Der Text soll informativ, leicht verständlich und suchmaschinenoptimiert sein."
