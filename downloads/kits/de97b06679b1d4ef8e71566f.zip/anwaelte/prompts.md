Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Anwälte (DACH) in der Du-Form, mit dem Hinweis, dass die Ergebnisse zu prüfen sind:

**Wichtiger Hinweis: Die Ergebnisse der KI sind stets kritisch zu prüfen, auf Richtigkeit und Vollständigkeit zu überprüfen und an den spezifischen Fall anzupassen. KI kann unterstützen, ersetzt aber nicht die juristische Expertise.**

*   "Analysiere den Sachverhalt: [kurze Beschreibung des Sachverhalts, z.B. 'Kaufvertrag über eine Immobilie, bei dem der Käufer Mängel nach der Übergabe rügt']. Ermittle die relevanten Anspruchsgrundlagen im deutschen Zivilrecht und skizziere die jeweiligen Voraussetzungen und Rechtsfolgen. Berücksichtige dabei insbesondere [spezifische Rechtsgebiete oder Paragraphen, z.B. 'Mängelgewährleistungsrecht nach §§ 434 ff. BGB']. Fasse die Ergebnisse prägnant zusammen."

*   "Formuliere einen Entwurf für ein Schreiben an die Gegenseite, in dem du [Name der Gegenseite oder 'die Gegenseite'] aufforderst, [spezifische Forderung, z.B. 'einen Betrag von X Euro zu zahlen' oder 'eine Handlung zu unterlassen']. Begründe die Forderung unter Verweis auf [relevante Rechtsnormen oder Vertragsbestimmungen]. Setze eine Frist bis zum [Datum] für die Erfüllung. Der Ton soll [gewünschter Ton, z.B. 'bestimmt, aber sachlich' oder 'eindringlich'] sein."

*   "Erstelle eine Liste mit den wesentlichen Argumenten für [deine Position, z.B. 'die Kündigung des Arbeitsverhältnisses durch den Arbeitgeber'] und dagegen [die Gegenposition, z.B. 'die Unwirksamkeit der Kündigung']. Berücksichtige dabei die aktuelle Rechtsprechung des [relevanten Gerichts, z.B. 'Bundesarbeitsgerichts'] und die einschlägigen Gesetzesvorschriften. Strukturiere die Argumente nach Pro und Contra."

*   "Fasse die Kerninhalte des Urteils des [Gericht, z.B. 'Bundesgerichtshofs'] vom [Datum] zum Aktenzeichen [Aktenzeichen] in Bezug auf [Thema des Urteils] zusammen. Welche Auswirkungen hat dieses Urteil auf die Praxis in [Rechtsgebiet, z.B. 'Mietrecht']? Identifiziere potenzielle Risiken und Chancen für Mandanten."

*   "Entwickle eine Strategie für die Verhandlung in einem Fall, in dem es um [kurze Beschreibung des Verhandlungsgegenstands, z.B. 'Schadensersatzansprüche nach einem Verkehrsunfall']. Welche Ziele verfolgen wir? Welche Zugeständnisse könnten wir machen? Welche Informationen benötigen wir noch? Berücksichtige dabei die Stärken und Schwächen unserer Position und der Gegenseite."

*   "Recherchiere relevante Fachartikel und Kommentare zu der Frage, ob [spezifische Rechtsfrage, z.B. 'die Verwendung von KI-generierten Texten im Gerichtsverfahren zulässig ist']. Identifiziere unterschiedliche Meinungen und Argumente. Fasse die Ergebnisse in einer kurzen Übersicht zusammen und gib eine Einschätzung ab, welche Position sich durchsetzen könnte."
