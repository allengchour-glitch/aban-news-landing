Absolut! Hier sind 6 erprobte, konkrete KI-Prompts für Friseure im DACH-Raum, in der Du-Form. Denk daran, die Ergebnisse immer kritisch zu prüfen und anzupassen!

---

**Wichtiger Hinweis:** Die Ergebnisse der KI sind Vorschläge und müssen immer auf Richtigkeit, Relevanz und den Tonfall deines Salons überprüft und gegebenenfalls angepasst werden.

---

* "Schreibe einen Instagram-Post, der unsere neue [Dienstleistung, z.B. Balayage-Technik, nachhaltige Haarpflegeserie] vorstellt. Betone, wie sie [Vorteil für den Kunden, z.B. natürliches Aussehen, gesundes Haar] bietet. Füge einen Call-to-Action hinzu, um einen Termin zu buchen und nutze relevante Emojis. Unser Salonname ist [Name des Salons]."
* "Entwickle drei kurze Textvorschläge für eine WhatsApp-Nachricht an unsere Stammkunden, um sie über unsere [Aktion, z.B. 10% Rabatt auf alle Produkte, kostenlose Kopfmassage bei Farbbehandlung] im Monat [Monat] zu informieren. Die Aktion ist gültig bis [Datum]. Bitte gib auch an, wie sie buchen können."
* "Erstelle einen Entwurf für einen Blogbeitrag auf unserer Website mit dem Titel '[Titel des Blogbeitrags, z.B. 5 Tipps für gesundes Haar im Winter, So findest du die perfekte Haarfarbe für deinen Hautton]'. Der Beitrag soll informativ sein, aber auch unsere Expertise als Friseure hervorheben. Füge einen Hinweis auf unsere Beratungsleistungen ein."
* "Formuliere eine Antwort auf eine 4-Sterne-Google-Bewertung, die lobt, aber auch erwähnt, dass die Wartezeit etwas lang war. Bedanke dich für das Lob, entschuldige dich für die Wartezeit und versichere, dass wir daran arbeiten, unsere Abläufe zu optimieren. Lade den Kunden ein, uns wieder zu besuchen."
* "Schreibe einen kurzen Text für einen Facebook-Post, der ein Vorher-Nachher-Bild unserer Arbeit zeigt (bitte Platzhalter für Beschreibung des Bildes lassen). Beschreibe die Verwandlung und erwähne die verwendete [Technik/Produktmarke]. Frage die Community, was sie von dem Ergebnis hält. Unser Salon ist spezialisiert auf [Spezialisierung, z.B. Blondtöne, Locken]."
* "Erstelle drei Betreffzeilen und einen kurzen E-Mail-Text für unseren Newsletter, der unsere Kunden über die Einführung unserer neuen Online-Terminbuchung informiert. Erkläre kurz die Vorteile (z.B. 24/7 verfügbar, einfache Handhabung) und füge einen klaren Link zur Buchungsseite hinzu: [Link zur Buchungsseite]."
