Hier sind 6 erprobte, konkrete KI-Prompts für Physiotherapeuten (DACH) zur direkten Verwendung. Bitte beachte, dass die Ergebnisse der KI stets kritisch geprüft und an die individuelle Situation angepasst werden müssen.

*   "Ich brauche einen Entwurf für einen Blogbeitrag über die Vorteile von [spezifische Therapieform, z.B. Manuelle Therapie] bei [spezifische Beschwerde, z.B. chronischen Rückenschmerzen]. Zielgruppe sind [Zielgruppe, z.B. aktive Menschen über 40]. Der Ton soll informativ und motivierend sein. Bitte erwähne, dass eine individuelle Diagnose und Behandlung durch einen Physiotherapeuten unerlässlich ist."

*   "Erstelle mir einen Social Media Post (Instagram/Facebook) für [Datum/Anlass, z.B. den Tag der Rückengesundheit]. Der Post soll auf die Bedeutung von [Thema, z.B. regelmäßiger Bewegung] für [Nutzen, z.B. eine gesunde Wirbelsäule] hinweisen. Füge einen Call-to-Action hinzu, der auf [Aktion, z.B. unsere Website für weitere Tipps] verweist. Verwende relevante Emojis und Hashtags."

*   "Formuliere eine E-Mail an einen Patienten, der [Grund, z.B. seine erste Behandlung bei uns hatte]. Die E-Mail soll sich für das Vertrauen bedanken, die nächsten Schritte (z.B. den nächsten Termin) kurz zusammenfassen und die Möglichkeit bieten, bei Fragen Kontakt aufzunehmen. Der Ton soll freundlich und professionell sein."

*   "Ich benötige Ideen für eine kurze Übungsanleitung (ca. 3-5 Übungen) für Patienten mit [spezifische Beschwerde, z.B. leichten Nackenschmerzen] zur Durchführung zu Hause. Die Übungen sollen einfach zu verstehen und ohne spezielle Geräte durchführbar sein. Bitte beschreibe jede Übung kurz und prägnant und gib Hinweise zur Wiederholungszahl und Dauer."

*   "Schreibe einen kurzen Text für unsere Website im Bereich 'Über uns'. Der Text soll unsere Philosophie als Physiotherapiepraxis [Name der Praxis] beschreiben, die sich auf [Schwerpunkte, z.B. ganzheitliche Behandlung und individuelle Betreuung] konzentriert. Erwähne kurz, was Patienten von uns erwarten können."

*   "Entwickle eine Liste von 3-5 Fragen, die ich einem neuen Patienten im Erstgespräch stellen kann, um ein umfassendes Bild seiner [Beschwerde/Situation, z.B. Rückenschmerzen] zu erhalten. Die Fragen sollen über die reinen Symptome hinausgehen und auch Aspekte wie [Beispiele, z.B. Alltagsbelastung, bisherige Behandlungen, persönliche Ziele] abdecken."
