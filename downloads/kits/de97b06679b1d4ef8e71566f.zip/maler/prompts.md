**Wichtiger Hinweis:** Die generierten Inhalte müssen immer auf Richtigkeit, Relevanz und den spezifischen Kontext deines Malerbetriebs geprüft und gegebenenfalls angepasst werden. KI-Tools sind Assistenten, keine Ersatz für menschliches Fachwissen.

Hier sind 6 erprobte, konkrete KI-Prompts für Maler (DACH):

*   "Ich brauche einen überzeugenden Fließtext für unsere neue Webseite, der die Vorteile einer professionellen Fassadenreinigung durch uns hervorhebt. Konzentriere dich auf Langlebigkeit, Werterhalt und ein ansprechendes Erscheinungsbild. Zielgruppe sind Hausbesitzer im Raum [deine Region]. Verwende eine freundliche, aber fachkundige Tonalität. Länge: ca. 200 Wörter."

*   "Erstelle 3 Social Media Posts (Instagram/Facebook) für unser Angebot 'Innenraumgestaltung'. Jeder Post soll einen anderen Aspekt beleuchten: 1. Farbberatung, 2. Tapeten-Trends, 3. Allergikerfreundliche Anstriche. Füge jeweils passende Emojis und relevante Hashtags hinzu. Die Posts sollen zum Kommentieren und Teilen anregen. Ziel ist es, neue Kunden für eine Beratung zu gewinnen."

*   "Formuliere eine E-Mail an potenzielle Geschäftskunden (Immobilienverwaltungen, Bauträger), in der wir unsere Expertise bei der Sanierung von Mehrfamilienhäusern vorstellen. Betone unsere Zuverlässigkeit, Termintreue und die hohe Qualität unserer Arbeit. Füge einen Call-to-Action für ein unverbindliches Erstgespräch hinzu. Die E-Mail sollte professionell und prägnant sein. Länge: ca. 150 Wörter."

*   "Ich benötige 5 kurze, prägnante Stichpunkte für eine Broschüre, die unsere Kernkompetenzen als Malerbetrieb zusammenfassen. Denke an Punkte wie 'Meisterbetrieb', 'nachhaltige Materialien', 'individuelle Lösungen', 'saubere Ausführung' und 'kostenlose Beratung'. Jeder Stichpunkt sollte maximal 10 Wörter lang sein."

*   "Schreibe einen Blogbeitrag zum Thema 'Die richtige Farbwahl für Ihr Schlafzimmer: So schaffen Sie eine Wohlfühloase'. Gehe auf psychologische Effekte von Farben ein (z.B. Blau beruhigend, Grün entspannend) und gib konkrete Farbbeispiele. Schließe mit einem Hinweis auf unsere professionelle Farbberatung ab. Länge: ca. 300-400 Wörter."

*   "Entwickle 3 Fragen für ein Kundenfeedback-Formular nach Abschluss eines Auftrags. Die Fragen sollen uns helfen, unsere Dienstleistungen zu verbessern. Denke an Aspekte wie 'Zufriedenheit mit dem Ergebnis', 'Kommunikation während des Projekts' und 'Weiterempfehlung'. Die Fragen sollen offen formuliert sein und Raum für Kommentare lassen."
