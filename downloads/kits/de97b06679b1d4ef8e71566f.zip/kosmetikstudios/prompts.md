Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Kosmetikstudios im DACH-Raum, die du direkt kopieren und anpassen kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und gegebenenfalls zu überarbeiten, da KI-Generierungen nicht immer perfekt sind.

---

**Hinweis:** Die Ergebnisse der KI sind Vorschläge. Bitte prüfe sie immer sorgfältig auf Richtigkeit, Tonalität und Passgenauigkeit für dein Studio, bevor du sie verwendest.

---

*   "Schreibe 3 kurze Social Media Posts (Instagram/Facebook) für unser Kosmetikstudio [Name des Studios] in [Stadt]. Wir möchten auf unsere neue Behandlung 'Hydra Glow Gesichtsbehandlung' aufmerksam machen, die für [Hauttyp/Problem, z.B. trockene, fahle Haut] ideal ist. Betone die sofort sichtbaren Ergebnisse und das Gefühl von Frische. Verwende Emojis und relevante Hashtags. Die Posts sollen zum Buchen über unsere Website [Link zur Website] oder Telefonnummer [Telefonnummer] anregen."

*   "Entwickle eine E-Mail für unsere bestehenden Kundinnen und Kunden, die sie über unsere aktuellen Herbst-Angebote informiert. Wir bieten [Angebot 1, z.B. 15% Rabatt auf alle Peelings] und [Angebot 2, z.B. eine kostenlose Handmassage bei jeder Gesichtsbehandlung über X Euro] an. Die Angebote sind gültig bis zum [Datum]. Erkläre kurz den Nutzen der Behandlungen für die Haut in der kalten Jahreszeit. Füge einen klaren Call-to-Action zum Buchen online oder telefonisch hinzu. Unser Studio heißt [Name des Studios] und befindet sich in [Stadt]."

*   "Formuliere 5 Fragen für eine kurze Umfrage, die wir unseren Kundinnen und Kunden nach einer Behandlung zukommen lassen möchten. Ziel ist es, Feedback zur Zufriedenheit mit der Behandlung 'Anti-Aging Deluxe Gesichtsbehandlung' und dem Ambiente unseres Studios 'Schönheitsoase [Name des Studios]' zu erhalten. Frage auch nach Verbesserungsvorschlägen und ob sie uns weiterempfehlen würden. Die Fragen sollen einfach und schnell zu beantworten sein."

*   "Erstelle einen kurzen Text für unsere Website-Startseite, der unser Kosmetikstudio [Name des Studios] in [Stadt] vorstellt. Wir legen Wert auf individuelle Beratung, hochwertige Produkte von [Marke 1] und [Marke 2] und eine entspannte Atmosphäre. Beschreibe unser Angebot kurz und prägnant, ohne zu viele Details zu nennen, und lade Besucher ein, unsere Behandlungen zu entdecken. Füge einen Satz über unsere Philosophie hinzu, z.B. 'Deine Schönheit ist unsere Leidenschaft'."

*   "Schreibe 3 verschiedene Überschriften für einen Blogbeitrag oder eine Landing Page zum Thema 'Hautpflege-Routine für den Winter'. Die Überschriften sollen neugierig machen und zum Weiterlesen anregen. Unser Studio heißt [Name des Studios] und wir möchten unsere Expertise im Bereich Hautpflege hervorheben. Die Überschriften sollen sich an Personen richten, die ihre Haut im Winter optimal pflegen möchten."

*   "Entwickle einen kurzen Skript-Entwurf für eine Instagram Story, in der wir eine unserer Mitarbeiterinnen, [Name der Mitarbeiterin], vorstellen. Sie ist unsere Expertin für [Spezialgebiet, z.B. Wimpernverlängerungen]. Sie soll kurz erzählen, was ihr an ihrer Arbeit am besten gefällt und warum sie [Name des Studios] liebt. Füge einen Call-to-Action hinzu, um Termine bei ihr zu buchen."
