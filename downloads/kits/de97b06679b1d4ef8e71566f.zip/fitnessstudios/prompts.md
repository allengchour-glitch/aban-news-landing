Hier sind 6 erprobte KI-Prompts für Fitnessstudios (DACH). Bitte beachte, dass die Ergebnisse der KI immer überprüft und bei Bedarf angepasst werden müssen.

*   "Du bist ein erfahrener Social Media Manager für Fitnessstudios. Erstelle 3 Instagram-Post-Ideen für unser Studio [Name des Fitnessstudios], die sich an Personen richten, die noch nie in einem Fitnessstudio waren. Fokus auf die Überwindung von Ängsten und die Betonung einer einladenden Atmosphäre. Verwende Emojis und Hashtags. Die Posts sollen zum kostenlosen Probetraining einladen."

*   "Schreibe einen kurzen, überzeugenden E-Mail-Text für unsere Newsletter-Abonnenten, die schon länger nicht mehr bei uns waren. Der Betreff soll Neugier wecken. Der Inhalt soll auf unsere neuen Kurse [Namen von 2-3 neuen Kursen] aufmerksam machen und einen speziellen Anreiz für die Rückkehr bieten, z.B. '[Anreiz, z.B. 10% Rabatt auf die nächste Monatsmitgliedschaft]'. Die E-Mail soll in der du-Form verfasst sein."

*   "Entwickle 5 knackige Slogans für eine lokale Werbekampagne unseres Fitnessstudios [Name des Fitnessstudios] in [Stadt/Region]. Die Slogans sollen sich an vielbeschäftigte Berufstätige richten, die wenig Zeit haben, aber fit bleiben möchten. Betone Effizienz und flexible Trainingsmöglichkeiten."

*   "Du bist ein Personal Trainer mit Fokus auf Ernährung. Erstelle 3 kurze, informative Tipps für unsere Social Media Kanäle zum Thema 'Gesunde Ernährung im Alltag', die leicht umsetzbar sind und keine extremen Einschränkungen fordern. Füge einen Call-to-Action hinzu, der auf unsere Ernährungsberatung verweist."

*   "Schreibe einen kurzen Blogbeitrag (ca. 200 Wörter) für unsere Website mit dem Titel 'Warum Krafttraining auch für [Zielgruppe, z.B. Frauen über 40] wichtig ist'. Erkläre die Vorteile auf verständliche Weise und entkräfte gängige Mythen. Beende den Beitrag mit einer Einladung zu einem kostenlosen Beratungsgespräch in unserem Studio."

*   "Formuliere 4 Fragen für eine Umfrage unter unseren Mitgliedern, um herauszufinden, welche neuen Kursangebote sie sich wünschen würden. Die Fragen sollen offen sein und Raum für eigene Vorschläge lassen. Füge eine Frage hinzu, die nach der bevorzugten Tageszeit für Kurse fragt."
