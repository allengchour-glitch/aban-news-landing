Gerne, hier sind 6 erprobte, konkrete KI-Prompts für die Gastronomie im DACH-Raum, die du direkt verwenden kannst. Denk daran, die Ergebnisse immer zu prüfen und bei Bedarf anzupassen, da KI-Modelle manchmal unerwartete Ausgaben liefern können.

*   **Wichtiger Hinweis:** Die Ergebnisse dieser Prompts müssen immer kritisch geprüft und an deine spezifischen Bedürfnisse und dein Branding angepasst werden. KI-Modelle können halluzinieren oder generische Inhalte liefern, die nicht immer perfekt passen.

---

*   "Entwickle 5 kreative und ansprechende Social-Media-Posts für unser [Restaurant/Café/Bar] in [Stadt/Region], um unsere [neue Speisekarte/Saisonangebote/Happy Hour] zu bewerben. Konzentriere dich auf die Verwendung von Emojis, Hashtags und einer direkten Ansprache. Zielgruppe sind [junge Paare/Familien/Geschäftsleute]. Füge einen Call-to-Action hinzu, der zur [Reservierung/Bestellung/Besuch] anregt."

*   "Schreibe einen kurzen, überzeugenden Text für unsere Website-Startseite, der unser [Restaurant/Café/Bar] in [Stadt/Region] vorstellt. Hebe dabei unsere [besondere Atmosphäre/frischen Zutaten/einzigartigen Cocktails] hervor. Der Text soll Neugier wecken und zum Weiterlesen anregen. Verwende eine freundliche und einladende Tonalität."

*   "Formuliere eine E-Mail an unsere Newsletter-Abonnenten, um sie über unser bevorstehendes [Event/Themenabend/Kochkurs] am [Datum] zu informieren. Beschreibe kurz, was sie erwartet, und nenne [2-3 Highlights]. Füge einen klaren Link zur [Anmeldung/Reservierung] hinzu und schaffe ein Gefühl der Exklusivität."

*   "Erstelle 3 verschiedene Textvorschläge für eine Google-Ads-Anzeige, die potenzielle Gäste in [Stadt/Region] auf unser [Restaurant/Café/Bar] aufmerksam machen soll. Jeder Vorschlag sollte eine einzigartige Überschrift und eine kurze, prägnante Beschreibung enthalten, die unsere [Spezialität/Lage/Preiskategorie] hervorhebt. Füge einen Call-to-Action hinzu."

*   "Schreibe 4 kurze, prägnante Antworten auf häufig gestellte Fragen (FAQs) für unsere Webseite oder Social-Media-Kanäle. Die Fragen sind: 'Sind Reservierungen notwendig?', 'Bietet ihr auch vegetarische/vegane Optionen an?', 'Habt ihr Parkmöglichkeiten?' und 'Wie sind eure Öffnungszeiten?'. Formuliere die Antworten klar und kundenfreundlich."

*   "Entwickle eine kurze, aber wirkungsvolle Beschreibung für unser [Gericht/Getränk] '[Name des Gerichts/Getränks]' auf der Speisekarte. Beschreibe die wichtigsten [Zutaten/Geschmacksprofile/Besonderheiten] so, dass dem Gast das Wasser im Mund zusammenläuft. Vermeide dabei zu viele Adjektive und konzentriere dich auf die Essenz."
