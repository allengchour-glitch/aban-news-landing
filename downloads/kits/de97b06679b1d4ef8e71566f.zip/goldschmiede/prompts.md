**Wichtiger Hinweis:** Die Ergebnisse der KI müssen immer sorgfältig geprüft und bei Bedarf angepasst werden, um fachliche Korrektheit und Markenidentität zu gewährleisten.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Goldschmiede (DACH):

*   "Ich brauche einen kurzen, ansprechenden Social-Media-Post (Instagram) für unseren neuen Ring ' [Name des Rings]'. Beschreibe, wie die [besondere Eigenschaft des Rings, z.B. "feine Gravur", "einzigartige Fassung"] die [gewünschte Emotion, z.B. "Eleganz", "Individualität"] unterstreicht. Füge einen Call-to-Action hinzu, der zum Besuch unserer Website [Link zur Website] oder zum direkten Kontakt auffordert. Verwende maximal 150 Wörter und relevante Emojis."

*   "Schreibe einen Entwurf für einen Newsletter-Abschnitt über die Bedeutung von [Art des Schmucks, z.B. "Verlobungsringen", "Erbschmuck"] als Ausdruck von [Wert, z.B. "Liebe und Verbundenheit", "Erinnerung und Geschichte"]. Erkläre, wie wir bei [Name des Unternehmens] diesen Wert durch [spezifische Handwerkskunst/Service, z.B. "individuelle Beratung", "hochwertige Materialien"] ehren. Der Ton soll persönlich und vertrauensvoll sein. Maximal 250 Wörter."

*   "Erstelle drei verschiedene Headline-Optionen für eine Anzeige, die unsere [Art des Schmucks, z.B. "handgefertigten Ohrringe", "personalisierbaren Anhänger"] bewirbt. Jede Headline soll eine andere Zielgruppe ansprechen: 1. Kunden, die nach einem besonderen Geschenk suchen. 2. Kunden, die Wert auf Nachhaltigkeit legen. 3. Kunden, die Individualität schätzen. Die Headlines sollen prägnant und neugierig machend sein."

*   "Ich benötige eine kurze Produktbeschreibung für unsere Website für das Schmuckstück '[Name des Schmuckstücks]'. Beschreibe die verwendeten Materialien ([Materialien, z.B. "18 Karat Gold", "Diamanten im Brillantschliff"]) und die [besondere Design-Philosophie/Inspiration, z.B. "zeitlose Eleganz", "naturnahe Formen"]. Hebe hervor, warum dieses Schmuckstück einzigartig ist und welche Emotionen es hervorrufen soll. Max. 100 Wörter."

*   "Formuliere eine Antwort auf eine Kundenanfrage per E-Mail, die sich nach den Kosten für eine [Art der Reparatur/Anfertigung, z.B. "Ringweitenänderung", "Anfertigung eines individuellen Anhängers"] erkundigt. Erkläre, dass eine genaue Preisangabe erst nach Begutachtung des Schmuckstücks möglich ist und lade den Kunden zu einem persönlichen Beratungsgespräch in unser Atelier ein. Gib unsere Kontaktdaten an. Der Ton soll freundlich und professionell sein."

*   "Schreibe einen kurzen Blogbeitrag (ca. 300 Wörter) über die Pflege von [Art des Schmucks, z.B. "Goldschmuck", "Perlenschmuck"]. Gib praktische Tipps zur Reinigung und Aufbewahrung, um die Langlebigkeit und den Glanz der Stücke zu erhalten. Erwähne auch, dass wir professionelle Reinigungs- und Pflegeservices anbieten. Verwende eine leicht verständliche Sprache."
