**Wichtiger Hinweis:** Die Ergebnisse der KI-Prompts sind Vorschläge und müssen immer auf Richtigkeit, Vollständigkeit und Angemessenheit überprüft und an Ihre spezifische Situation angepasst werden.

Hier sind 6 erprobte, konkrete KI-Prompts für Immobilienmakler im DACH-Raum:

*   "Erstelle eine überzeugende Objektbeschreibung für diese 3-Zimmer-Wohnung in [Stadtteil, Stadt]. Sie verfügt über [Anzahl] Balkone, eine [Art] Küche und liegt in einem [ruhigen/lebhaften] Viertel mit guter Anbindung an [Verkehrsmittel/Infrastruktur]. Betone die Vorteile für [Zielgruppe, z.B. junge Paare, Pendler] und nutze eine [freundliche/seriöse] Tonalität. Die Wohnfläche beträgt [X] qm, der Kaufpreis ist [Y] Euro."

*   "Formuliere eine E-Mail an einen potenziellen Käufer, der sich für die Immobilie in [Adresse] interessiert. Erwähne kurz die Highlights der Immobilie wie [Merkmal 1, Merkmal 2] und biete einen Besichtigungstermin an. Schlage zwei konkrete Terminvorschläge vor: [Datum, Uhrzeit] und [Datum, Uhrzeit]. Frage nach seiner bevorzugten Kontaktmethode für die Terminbestätigung."

*   "Entwickle 3 Social-Media-Posts (für Facebook/Instagram) für die Vermarktung dieses Einfamilienhauses in [Ort]. Das Haus hat [Anzahl] Zimmer, einen [Größe] Garten und wurde [Jahr] gebaut. Betone die familienfreundliche Umgebung und die Nähe zu [Schulen/Natur]. Verwende passende Emojis und Hashtags wie #Immobilien [Ort], #Einfamilienhaus, #Traumhaus. Füge einen Call-to-Action hinzu, z.B. 'Kontaktiere uns für eine Besichtigung!'"

*   "Schreibe einen kurzen Blogbeitrag (ca. 200 Wörter) über die aktuellen Trends auf dem Immobilienmarkt in [Region/Stadt]. Gehe auf die Themen [Zinsentwicklung/Nachhaltigkeit/Smart Home] ein und erkläre, welche Auswirkungen diese auf Käufer und Verkäufer haben könnten. Gib einen Tipp, wie man sich in diesem Markt am besten positioniert."

*   "Formuliere eine Antwort auf eine Kundenanfrage per E-Mail, in der er nach dem Energieausweis für die Immobilie in [Adresse] fragt. Erkläre, dass der Energieausweis vorliegt und die Effizienzklasse [A/B/C etc.] beträgt. Biete an, weitere Details zu den Energiewerten zu erläutern und schlage ein kurzes Telefonat vor, um offene Fragen zu klären."

*   "Erstelle eine Liste mit 5 Fragen, die ich einem Verkäufer bei der Erstberatung stellen sollte, um ein umfassendes Bild seiner Immobilie und seiner Verkaufsziele zu erhalten. Die Fragen sollen sich auf [Zustand der Immobilie/Verkaufszeitpunkt/Motivation] konzentrieren und mir helfen, den bestmöglichen Service zu bieten."
