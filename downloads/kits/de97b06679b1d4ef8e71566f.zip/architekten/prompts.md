**Wichtiger Hinweis:** Die Ergebnisse der KI-Prompts müssen stets kritisch geprüft und an die spezifischen Anforderungen jedes Projekts angepasst werden. KI ist ein Werkzeug, kein Ersatz für Fachwissen und Erfahrung.

Hier sind 6 erprobte, konkrete KI-Prompts für Architekten (DACH):

*   "Entwerfe ein nachhaltiges Mehrfamilienhaus in [Stadt/Region] mit [Anzahl] Wohneinheiten. Berücksichtige dabei die lokalen Bauvorschriften, eine hohe Energieeffizienz (z.B. KfW 40 Plus Standard) und die Integration erneuerbarer Energien. Der Entwurf soll eine ansprechende Ästhetik mit funktionalen Grundrissen verbinden und auf [spezifische Zielgruppe, z.B. junge Familien, Senioren] zugeschnitten sein. Welche Materialien schlägst du vor, um diese Ziele zu erreichen?"

*   "Analysiere die Baukosten für ein [Gebäudetyp, z.B. Bürogebäude, Einfamilienhaus] in [Stadt/Region] mit einer Bruttogeschossfläche von [X] m². Berücksichtige dabei die aktuellen Marktpreise für [spezifische Materialien, z.B. Beton, Holz, Glas] und die regionalen Lohnkosten. Erstelle eine grobe Kostenschätzung für die Gewerke [X, Y, Z] und identifiziere potenzielle Kostentreiber sowie Einsparpotenziale."

*   "Erstelle eine detaillierte Leistungsbeschreibung für die Sanierung der Fassade eines Bestandsgebäudes aus den [Jahrzehnt, z.B. 1970er Jahre] in [Stadt/Region]. Die Sanierung soll die Energieeffizienz verbessern, das Erscheinungsbild modernisieren und die Lebensdauer des Gebäudes verlängern. Welche Maßnahmen sind hierfür notwendig (z.B. Dämmung, Fenstererneuerung, Putzarbeiten) und welche Materialien empfiehlst du unter Berücksichtigung der Denkmalschutzauflagen (falls zutreffend)?"

*   "Generiere innovative Ideen für die Gestaltung eines öffentlichen Platzes in [Stadt/Region] mit einer Fläche von [X] m². Der Platz soll als Treffpunkt für die Gemeinschaft dienen, die Aufenthaltsqualität erhöhen und die lokale Identität stärken. Berücksichtige dabei Aspekte wie Begrünung, Wasserelemente, Sitzgelegenheiten, Beleuchtung und die Integration von Kunst im öffentlichen Raum. Welche Materialien und Pflanzen eignen sich für das lokale Klima?"

*   "Formuliere eine Anfrage an die Baubehörde für eine Baugenehmigung für ein [Gebäudetyp] in [Adresse/Flurstück]. Beschreibe das Bauvorhaben präzise, inklusive der geplanten Nutzung, der Abmessungen und der geplanten Erschließung. Welche Unterlagen sind typischerweise für einen solchen Antrag in [Bundesland] erforderlich und welche Besonderheiten müssen beachtet werden?"

*   "Entwickle ein Konzept für die Innenraumgestaltung eines [Raumtyp, z.B. Wohnzimmer, Konferenzraum, Arztpraxis] unter Berücksichtigung der Prinzipien des [spezifischer Stil, z.B. minimalistischen Designs, skandinavischen Stils, biophilen Designs]. Welche Farbpalette, Materialien und Möbelstücke schlägst du vor, um eine bestimmte Atmosphäre (z.B. beruhigend, inspirierend, funktional) zu schaffen? Berücksichtige auch die Beleuchtungsplanung und die Akustik."
