**Always verify AI-generated content for accuracy and compliance with current tax laws.**

* "Erstelle einen Entwurf für einen Mandantenbrief, der die Änderungen im [Steuerjahr] bezüglich der [spezifischen Steuerart, z.B. Umsatzsteuer] erläutert und die Auswirkungen auf [Art des Unternehmens, z.B. Kleinunternehmer] darstellt. Füge eine Checkliste der benötigten Unterlagen für die Jahresabschlusserstellung hinzu. Der Ton soll informativ und leicht verständlich sein."

* "Analysiere den Jahresabschluss von [Mandantenname] für das Geschäftsjahr [Geschäftsjahr]. Identifiziere potenzielle Optimierungsmöglichkeiten in Bezug auf [spezifischer Bereich, z.B. Abschreibungen, Rückstellungen] und schlage konkrete Maßnahmen vor, die zu einer Steuerersparnis führen könnten. Begründe jede Maßnahme kurz."

* "Formuliere eine E-Mail-Antwort an einen Mandanten, der nach der steuerlichen Behandlung von [spezifische Investition, z.B. Photovoltaikanlage, Elektrofahrzeug] fragt. Erkläre die relevanten Paragraphen des Einkommensteuergesetzes und weise auf mögliche Förderprogramme oder Besonderheiten hin. Füge einen Hinweis auf die Notwendigkeit einer individuellen Beratung hinzu."

* "Erstelle eine Liste der wichtigsten Fristen für die Steuererklärung [Steuerjahr] für [Art des Mandanten, z.B. GmbH, Einzelunternehmen]. Füge auch Fristen für relevante Meldepflichten wie [Beispiel: Umsatzsteuervoranmeldung, Lohnsteueranmeldung] hinzu. Strukturiere die Liste übersichtlich nach Datum."

* "Entwickle einen Entwurf für eine Präsentation zum Thema 'Steuerliche Aspekte der Unternehmensgründung' für Existenzgründer. Beziehe dich auf die Wahl der Rechtsform, die wichtigsten Steuerarten (Umsatzsteuer, Einkommensteuer, Gewerbesteuer) und die Bedeutung einer sorgfältigen Buchführung. Die Präsentation soll die wichtigsten Punkte auf maximal 10 Folien zusammenfassen."

* "Verfasse einen Blogbeitrag für unsere Kanzlei-Website zum Thema 'Was tun bei einer Betriebsprüfung?'. Erkläre die typischen Abläufe, die Rechte und Pflichten des Steuerpflichtigen und gib praktische Tipps zur Vorbereitung und zum Umgang mit dem Prüfer. Der Ton soll vertrauenswürdig und beruhigend sein."
