**Always review and refine AI-generated content to ensure accuracy, tone, and alignment with your coaching philosophy.**

*   "You are an expert coach. I am a [type of coach, e.g., business coach, life coach]. My client is struggling with [specific client challenge, e.g., procrastination, imposter syndrome, setting clear goals]. Generate 3 actionable, empathetic coaching questions I can ask them to help them gain clarity and move forward. Focus on open-ended questions that encourage self-reflection."

*   "As a marketing strategist for coaches, draft 3 compelling social media captions (for [platform, e.g., LinkedIn, Instagram]) to attract potential clients who are experiencing [common client pain point, e.g., feeling stuck, overwhelmed by their career, lacking confidence]. Include a call to action to [desired action, e.g., book a discovery call, download a free resource]."

*   "I need a short, inspiring email subject line and a 2-paragraph email body for my coaching newsletter. The theme is [newsletter theme, e.g., overcoming limiting beliefs, building resilience, finding your purpose]. The goal is to encourage engagement and remind subscribers of the value of coaching. Keep the tone [desired tone, e.g., encouraging, empowering, insightful]."

*   "My client is facing a decision about [specific decision, e.g., changing careers, starting a new project, delegating tasks]. As a coach, help me brainstorm 5 potential pros and 5 potential cons they might consider, from a holistic perspective (e.g., emotional, financial, time commitment). Also, suggest one powerful question I can ask to help them weigh these factors."

*   "I'm preparing for a coaching session with a client who wants to improve their [specific skill or area, e.g., public speaking, time management, networking]. Generate 3 practical, step-by-step exercises or strategies they can implement *this week* to make tangible progress. Each suggestion should be concise and actionable."

*   "My coaching niche is [your coaching niche, e.g., leadership development, wellness coaching, career transition]. I want to create a short, engaging blog post (approx. 300 words) titled '[Blog Post Title]'. The post should address [key problem or benefit for your niche] and offer [1-2 actionable tips]. Conclude with a gentle call to action to learn more about my coaching services."
