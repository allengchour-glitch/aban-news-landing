**Always review AI-generated content for accuracy, relevance, and originality before use.**

* "Generate a detailed architectural brief for a [building type, e.g., sustainable community center] in [city/region], focusing on [key design principles, e.g., passive house standards, local material sourcing, community engagement]. Include considerations for [specific features, e.g., flexible event spaces, integrated green infrastructure, accessibility for all ages]."

* "Critique the structural integrity and aesthetic appeal of the proposed [building component, e.g., cantilevered balcony system] for the [project name] project, considering [specific constraints, e.g., seismic activity, material limitations, budget]. Suggest three alternative approaches with their respective pros and cons."

* "Outline a comprehensive project timeline and resource allocation plan for the design development phase of a [project type, e.g., mixed-use high-rise] with a target completion date of [date]. Include key milestones, required team roles, and estimated hours for each task."

* "Draft a persuasive client presentation script for a [project phase, e.g., concept design review] of the [project name]. Emphasize the unique selling points of our design, address potential client concerns regarding [specific concerns, e.g., cost, maintenance, aesthetics], and clearly articulate the next steps."

* "Research and summarize the latest building regulations and zoning ordinances relevant to the construction of a [building type, e.g., multi-family residential building] in [specific municipality/country]. Highlight any recent changes or upcoming amendments that could impact our design."

* "Develop a series of five compelling social media posts (LinkedIn, Instagram) to showcase our firm's recent completion of the [project name]. Focus on [specific project highlights, e.g., innovative use of materials, sustainable design features, positive community impact] and include relevant hashtags."
