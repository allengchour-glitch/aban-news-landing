Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Ärzte im DACH-Raum, die du direkt kopieren und anpassen kannst. Denk bitte daran, dass die Ergebnisse der KI immer kritisch geprüft und im Kontext deiner medizinischen Expertise bewertet werden müssen. Die KI ist ein Werkzeug, kein Ersatz für dein Fachwissen.

---

*   "Ich benötige eine **Zusammenfassung der neuesten evidenzbasierten Leitlinien** für die Diagnose und Behandlung von [Krankheit/Zustand, z.B. Typ-2-Diabetes] gemäß den Empfehlungen der [z.B. AWMF, DGIM, ÖDG, SGED]. Bitte konzentriere dich auf die wichtigsten Änderungen der letzten 2 Jahre und nenne die Quellen."

*   "Erstelle einen **Entwurf für einen Patienteninformationsbogen** zum Thema [Medikament/Behandlung, z.B. 'Einnahme von Antikoagulantien nach Herzklappenersatz']. Der Text soll verständlich, aber präzise sein, die wichtigsten Risiken und Nebenwirkungen nennen sowie Verhaltensregeln im Alltag. Die Zielgruppe sind Patienten mit durchschnittlichem Bildungsniveau."

*   "Ich habe einen Patienten mit [Symptom 1, z.B. persistierendem Husten seit 3 Wochen] und [Symptom 2, z.B. leichtem Fieber]. Die bisherigen Befunde sind [Befund 1, z.B. unauffälliges Röntgen-Thorax] und [Befund 2, z.B. negative CRP-Werte]. Welche **differenzialdiagnostischen Überlegungen** sollte ich anstellen und welche **weiteren diagnostischen Schritte** wären in diesem Fall sinnvoll? Bitte nenne auch seltene, aber relevante Ursachen."

*   "Formuliere eine **E-Mail an einen Fachkollegen** (z.B. Radiologen, Internisten), um einen Patienten mit [Patientenfall, z.B. 'unklarer Abdominalschmerz, V.a. Morbus Crohn'] zur weiteren Abklärung zu überweisen. Beschreibe prägnant die Anamnese, bisherige Befunde und die Fragestellung. Bitte achte auf eine professionelle und kollegiale Tonalität."

*   "Bitte erstelle eine **Liste von 5-7 häufig gestellten Fragen (FAQs)** von Patienten zum Thema [medizinischer Eingriff/Diagnose, z.B. 'Koloskopie zur Darmkrebsvorsorge'] und gib jeweils eine **kurze, patientenfreundliche Antwort**. Die Antworten sollen Ängste nehmen und wichtige Informationen vermitteln."

*   "Ich suche nach aktuellen **Forschungsergebnissen oder klinischen Studien** zu [Therapieansatz/Medikament, z.B. 'neue SGLT2-Inhibitoren bei Herzinsuffizienz mit erhaltener Ejektionsfraktion'] aus den letzten 1-2 Jahren. Bitte gib mir eine kurze Zusammenfassung der wichtigsten Erkenntnisse und nenne die Studiennamen oder Autoren, falls möglich."
