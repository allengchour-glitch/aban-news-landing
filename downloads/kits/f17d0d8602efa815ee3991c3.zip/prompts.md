**Wichtiger Hinweis:** Die generierten Ergebnisse der KI müssen stets kritisch geprüft und auf ihre Richtigkeit und Vollständigkeit hin überprüft werden. Die KI ist ein Werkzeug zur Unterstützung, ersetzt aber nicht die medizinische Expertise.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Ärzte (DACH):

*   "Erstelle eine prägnante Zusammenfassung der wichtigsten Studienergebnisse aus [Studienname/DOI] bezüglich der Wirksamkeit von [Medikament/Therapie] bei [Krankheitsbild]. Achte dabei auf die Methodik, die primären Endpunkte und die relevantesten Nebenwirkungen. Formuliere die Zusammenfassung so, dass sie für eine schnelle Einschätzung im Praxisalltag geeignet ist."

*   "Ich habe einen Patienten mit [Symptom 1], [Symptom 2] und einer Vorgeschichte von [Vorerkrankung]. Welche Differentialdiagnosen kommen in Betracht und welche initialen diagnostischen Schritte würdest du empfehlen, um diese abzuklären? Begründe deine Vorschläge kurz."

*   "Formuliere einen Entwurf für ein Aufklärungsgespräch mit einem Patienten, der sich einer [Operation/Behandlung] unterziehen soll. Gehe auf die wichtigsten Risiken, Vorteile und Alternativen ein und nutze eine verständliche Sprache. Füge auch einen Abschnitt zu möglichen Komplikationen und deren Management hinzu."

*   "Analysiere die neuesten Leitlinien der [Fachgesellschaft, z.B. DGIM] zu [Krankheitsbild, z.B. Diabetes mellitus Typ 2] und identifiziere die drei wichtigsten Änderungen oder Neuerungen im Vergleich zur vorherigen Version. Stelle diese kurz und prägnant dar und nenne die Quellenangaben."

*   "Ich benötige eine Übersicht über die aktuellen Therapieoptionen für [seltenes Krankheitsbild] bei erwachsenen Patienten. Berücksichtige dabei sowohl medikamentöse als auch nicht-medikamentöse Ansätze und gib an, welche Evidenzklasse die jeweiligen Empfehlungen haben. Nenne auch relevante Studien oder Publikationen."

*   "Verfasse einen kurzen, patientenfreundlichen Text über [Gesundheitsthema, z.B. Prävention von Herz-Kreislauf-Erkrankungen], der auf unserer Praxis-Website veröffentlicht werden kann. Erkläre die wichtigsten Risikofaktoren und gebe konkrete Tipps zur Lebensstiländerung. Achte auf eine positive und motivierende Sprache."
