**Wichtiger Hinweis:** Die generierten Ergebnisse der KI sind stets kritisch zu prüfen und dürfen nicht ungeprüft in die Praxis übernommen werden. Sie dienen als Unterstützung und Inspiration, ersetzen aber nicht die professionelle Expertise und das Urteilsvermögen.

Hier sind 6 erprobte, konkrete KI-Prompts für Ärzte (DACH):

*   "Du bist ein erfahrener medizinischer Fachredakteur. Erstelle einen kurzen, prägnanten Patienteninformationsflyer zum Thema '[Krankheitsbild]' für eine Zielgruppe mit durchschnittlichem Bildungsniveau. Erkläre die wichtigsten Symptome, Ursachen, Diagnosemethoden und Behandlungsoptionen. Verwende einfache Sprache und vermeide medizinischen Fachjargon, wo immer möglich. Füge einen Abschnitt mit Tipps zur Selbsthilfe und wann ein Arzt aufzusuchen ist hinzu."

*   "Analysiere die neuesten Forschungsergebnisse zu '[Medikament/Therapie]' und fasse die wichtigsten Erkenntnisse in einem kurzen Abstract zusammen. Gehe dabei auf die Studiendesigns, die signifikantesten Ergebnisse (positiv wie negativ) und mögliche klinische Implikationen ein. Nenne mindestens drei relevante Studien (mit DOI oder Publikationsort, falls verfügbar) als Referenz."

*   "Entwickle eine Liste von fünf häufig gestellten Fragen (FAQs) von Patienten zum Thema '[Medizinischer Eingriff/Diagnoseverfahren]'. Formuliere prägnante und verständliche Antworten, die Ängste nehmen und wichtige Informationen vermitteln. Berücksichtige dabei Aspekte wie Vorbereitung, Ablauf, mögliche Risiken und Nachsorge."

*   "Du bist ein Experte für medizinische Kommunikation. Formuliere einen Entwurf für eine E-Mail an Patienten, die über eine bevorstehende Änderung in der Praxisorganisation informiert werden sollen (z.B. neue Sprechzeiten, Einführung einer Online-Terminbuchung, Vertretung). Der Ton soll professionell, freundlich und informativ sein. Betone die Vorteile für die Patienten und biete Kontaktmöglichkeiten für Rückfragen an."

*   "Erstelle eine Checkliste für die Anamnese bei einem Patienten mit Verdacht auf '[Spezifisches Symptom/Krankheitsbild]'. Berücksichtige dabei sowohl allgemeine Fragen (z.B. Beginn, Dauer, Intensität) als auch spezifische Fragen, die für die Differentialdiagnose relevant sind. Füge auch Fragen zu relevanten Vorerkrankungen, Medikamenten und sozialen Faktoren hinzu."

*   "Du bist ein medizinischer Berater. Bewerte die Vor- und Nachteile von '[Neue Technologie/Behandlungsmethode]' im Vergleich zu etablierten Ansätzen. Berücksichtige dabei Aspekte wie Effektivität, Sicherheit, Kosten, Patientenakzeptanz und mögliche ethische Implikationen. Formuliere eine Empfehlung, unter welchen Umständen die neue Methode sinnvoll sein könnte und wann nicht."
