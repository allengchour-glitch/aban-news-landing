**Always review AI-generated content for accuracy and suitability before use.**

* "I need a concise, engaging social media post (under 280 characters) announcing our new [product/feature name]. Focus on the key benefit: [specific benefit]. Include a call to action: [call to action, e.g., 'Learn more at our website!']. Use relevant emojis: [emoji suggestions]."
* "Generate 3 distinct blog post title ideas for an article about [topic]. Each title should be compelling and include a keyword: [keyword]. Aim for variety in tone (e.g., informative, curious, problem-solving)."
* "Write a short, professional email (under 150 words) to [recipient's name] requesting a meeting to discuss [meeting purpose]. Propose 2-3 specific dates/times: [date/time options]. End with a clear call to action."
* "Create 5 bullet points summarizing the main takeaways from the following text: [paste text here]. Each bullet point should be no more than 15 words."
* "Develop 3 unique ideas for a marketing campaign targeting [target audience] for our [product/service]. Each idea should include a brief description of the concept and a suggested primary channel (e.g., social media, email, video)."
* "Draft a customer testimonial (1-2 sentences) highlighting the positive impact of our [product/service] on [customer's specific problem/need]. Focus on the benefit: [specific benefit]. Use a positive and authentic tone."
