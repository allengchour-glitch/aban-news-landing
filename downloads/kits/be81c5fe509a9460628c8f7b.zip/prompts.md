**Always review and verify the AI's output for accuracy and completeness before using it.**

*   "Erstelle einen Entwurf für ein Mandantenrundschreiben zum Jahreswechsel 2023/2024, das die wichtigsten steuerlichen Änderungen und Fristen für [Zielgruppe, z.B. Kleinunternehmer, GmbH-Geschäftsführer] zusammenfasst. Füge einen Call-to-Action für ein Beratungsgespräch hinzu."
*   "Formuliere eine E-Mail an einen potenziellen Neumandanten, der sich nach den Kosten für die Erstellung einer Einkommensteuererklärung erkundigt hat. Erkläre kurz den Leistungsumfang und bitte um weitere Informationen zur Erstellung eines individuellen Angebots."
*   "Entwickle eine Checkliste für die Unterlagen, die ein Mandant für die Erstellung seiner Umsatzsteuervoranmeldung im [Quartal/Monat] [Jahr] benötigt. Berücksichtige dabei gängige Belege und Besonderheiten für [Branche, z.B. Online-Handel]."
*   "Schreibe einen kurzen Blogbeitrag (ca. 300 Wörter) zum Thema 'Homeoffice und Steuern: Was Arbeitnehmer wissen müssen' für unsere Kanzlei-Website. Erkläre die wichtigsten Abzugsmöglichkeiten und Voraussetzungen."
*   "Erstelle eine Vorlage für eine Vollmacht zur Vertretung in Steuersachen, die alle notwendigen Angaben gemäß § 80 AO enthält und die Bevollmächtigung für [spezifische Aufgaben, z.B. Einspruchsverfahren, Einsicht in Akten] umfasst."
*   "Fasse die wesentlichen Änderungen des [spezifisches Gesetz, z.B. Wachstumschancengesetzes] in Bezug auf [spezifischer Bereich, z.B. Abschreibungen, Investitionsabzugsbetrag] prägnant zusammen und nenne die relevanten Paragraphen."
