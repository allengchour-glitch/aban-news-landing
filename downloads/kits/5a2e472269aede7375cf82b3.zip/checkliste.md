# Action checklist — AI in daily work

- [ ] Pick one recurring writing task (e.g. quotes, emails).
- [ ] Adapt one prompt from the pack and use it daily for a week.
- [ ] Always proofread results — facts/numbers come from you.
- [ ] For sensitive data, only use tools with clear EU data processing.
- [ ] Save what worked as a template. Drop what didn't.
