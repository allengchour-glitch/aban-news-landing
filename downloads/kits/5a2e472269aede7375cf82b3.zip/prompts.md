**Important Note:** AI-generated content should always be reviewed for accuracy, tone, and suitability before use.

Here are 6 proven, concrete copy-paste AI prompts for Handwerker (tradespeople):

*   "Erstelle 3 kurze, überzeugende Social Media Posts für [Handwerksbetrieb] über unsere [Dienstleistung, z.B. Badsanierung]. Der Fokus liegt auf [Vorteil für den Kunden, z.B. stressfreie Abwicklung]. Füge relevante Hashtags hinzu."

*   "Schreibe einen Entwurf für eine E-Mail an einen potenziellen Neukunden, der sich nach [spezifischer Dienstleistung, z.B. Heizungswartung] erkundigt hat. Betone unsere [Alleinstellungsmerkmal, z.B. schnelle Reaktionszeit] und biete einen [nächsten Schritt, z.B. kostenlosen Beratungstermin] an."

*   "Formuliere 5 prägnante Stichpunkte für unsere 'Über uns'-Seite auf der Website. Sie sollen unsere [Unternehmenswerte, z.B. Zuverlässigkeit, Qualität, Kundennähe] hervorheben und kurz unsere [Kernkompetenzen, z.B. langjährige Erfahrung in der Elektrotechnik] beschreiben."

*   "Entwickle 3 verschiedene Überschriften für einen Blogbeitrag zum Thema '[Problem des Kunden, z.B. Schimmel im Bad beseitigen]'. Die Überschriften sollen neugierig machen und den Leser zum Klicken anregen."

*   "Verfasse eine kurze, professionelle Antwort auf eine 4-Sterne-Bewertung auf Google, die besagt: 'Gute Arbeit, aber die Kommunikation war manchmal etwas schleppend.' Bedanke dich für das Feedback und zeige Verständnis für den Kritikpunkt."

*   "Erstelle eine Liste von 10 Fragen, die wir unseren Kunden vor Beginn eines [Projekttyp, z.B. Küchenumbau] stellen sollten, um alle wichtigen Details zu erfassen und Missverständnisse zu vermeiden."
