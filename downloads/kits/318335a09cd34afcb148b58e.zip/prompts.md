**Important Note:** AI-generated content should always be reviewed and edited by a qualified professional to ensure accuracy, safety, and adherence to best practices.

Here are 6 proven, concrete copy-paste AI prompts for Physiotherapists:

*   "Generate a patient-friendly explanation of [condition, e.g., 'rotator cuff tendinopathy'], including common symptoms, typical causes, and a brief overview of how physiotherapy can help. Focus on clear, concise language and avoid medical jargon."

*   "Create a draft exercise program for a patient recovering from [injury/surgery, e.g., 'ACL reconstruction, 6 weeks post-op']. Include 3-4 exercises focusing on [specific goals, e.g., 'quadriceps strengthening and knee flexion range of motion']. For each exercise, provide a brief description, recommended repetitions/sets, and any important precautions."

*   "Write a social media post (for [platform, e.g., 'Instagram']) promoting the benefits of physiotherapy for [target audience/condition, e.g., 'office workers experiencing neck pain']. Include a call to action to 'book a consultation' and suggest 2-3 relevant hashtags."

*   "Develop a script for a short educational video (approximately 60-90 seconds) explaining the importance of [topic, e.g., 'proper posture during prolonged sitting']. Include key takeaways and a practical tip that viewers can implement immediately."

*   "Draft an email to a referring physician, providing an update on patient [Patient Name]'s progress. Highlight key improvements in [specific areas, e.g., 'pain levels and functional mobility'], outline the current treatment plan, and suggest the next steps for ongoing care."

*   "Generate 3-4 frequently asked questions (FAQs) about [service/treatment, e.g., 'dry needling'] for our clinic's website. For each question, provide a concise and informative answer that addresses common patient concerns."
