**Wichtiger Hinweis:** Die Ergebnisse dieser KI-Prompts sind Vorschläge und müssen stets kritisch geprüft und an die individuelle Situation angepasst werden. Sie ersetzen keine professionelle Beratung oder Diagnostik.

Hier sind 6 erprobte, konkrete KI-Prompts für Physiotherapeuten (DACH):

* "Ich benötige einen Entwurf für einen Social-Media-Post (Instagram, Facebook) zur Aufklärung über die Vorteile von [Therapieform, z.B. Manuelle Therapie] bei [häufiges Beschwerdebild, z.B. chronischen Rückenschmerzen]. Der Post soll [Zielgruppe, z.B. Büroangestellte] ansprechen und [Call-to-Action, z.B. einen Termin vereinbaren] beinhalten. Bitte verwende eine verständliche Sprache und vermeide Fachjargon."

* "Erstelle eine kurze, prägnante E-Mail an einen Patienten, der nach [Anzahl] Behandlungen seine Therapie beendet hat. Die E-Mail soll sich für das Vertrauen bedanken, auf die erreichten Fortschritte hinweisen und [Empfehlung, z.B. regelmäßige Übungen zu Hause fortzusetzen] sowie [Angebot, z.B. bei Bedarf wieder Kontakt aufzunehmen] enthalten. Die Sprache soll freundlich und professionell sein."

* "Ich brauche Ideen für [Anzahl] Übungen, die ein Patient mit [Diagnose, z.B. Schulterimpingement] zu Hause durchführen kann, um die [Ziel, z.B. Beweglichkeit zu verbessern und Schmerzen zu reduzieren]. Die Übungen sollen ohne spezielle Geräte durchführbar sein und eine kurze Anleitung sowie Hinweise zu [wichtige Aspekte, z.B. Wiederholungen und Intensität] enthalten."

* "Formuliere einen Text für die 'Über uns'-Sektion meiner Physiotherapie-Praxis-Website. Der Text soll meine [Anzahl] Jahre Erfahrung, meine Spezialisierung auf [Spezialisierung, z.B. Sportphysiotherapie] und meine Philosophie, [Philosophie, z.B. ganzheitliche Behandlung], hervorheben. Die Sprache soll vertrauenswürdig und einladend sein."

* "Gib mir Vorschläge für [Anzahl] Fragen, die ich einem neuen Patienten mit [Beschwerdebild, z.B. Nackenschmerzen] stellen kann, um ein umfassendes Bild seiner Situation zu erhalten. Die Fragen sollen sowohl die körperlichen Symptome als auch [weitere Aspekte, z.B. Alltagsbelastungen und psychische Faktoren] beleuchten."

* "Entwickle einen kurzen Text für einen Flyer, der auf die Prävention von [Beschwerdebild, z.B. Bandscheibenvorfällen] abzielt. Der Flyer soll [Zielgruppe, z.B. Menschen mit sitzender Tätigkeit] ansprechen und [Anzahl] einfache Tipps zur Vorbeugung sowie einen Hinweis auf die Möglichkeit einer professionellen Beratung in meiner Praxis enthalten."
