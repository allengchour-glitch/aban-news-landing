**Wichtiger Hinweis:** Die generierten Inhalte müssen sorgfältig auf Richtigkeit, Tonalität und Markenpassung überprüft und gegebenenfalls angepasst werden. Künstliche Intelligenz kann Fehler machen.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Reinigungsfirmen (DACH):

*   "Du bist ein erfahrener Content Creator für Reinigungsfirmen. Erstelle einen kurzen Social-Media-Post (max. 150 Wörter) für [Plattform, z.B. Instagram], der unsere professionelle Büroreinigung bewirbt. Fokus liegt auf den Vorteilen für die Mitarbeiterproduktivität und das Wohlbefinden. Nutze Emojis und einen Call-to-Action. Zielgruppe: KMU-Geschäftsführer in [Stadt/Region]."

*   "Du bist ein E-Mail-Marketing-Experte. Entwerfe eine kurze E-Mail (max. 200 Wörter) für potenzielle Neukunden, die sich für unsere Gebäudereinigungsdienste interessieren. Die E-Mail soll den Mehrwert unserer individuellen Reinigungspläne hervorheben und zu einer kostenlosen Beratung einladen. Betreffzeile und ein klarer Call-to-Action sind Pflicht. Zielgruppe: Hausverwaltungen in [Stadt/Region]."

*   "Du bist ein SEO-Texter. Schreibe einen kurzen Blogbeitrag (ca. 300 Wörter) zum Thema 'Die Bedeutung einer professionellen Teppichreinigung für ein gesundes Raumklima'. Integriere die Keywords 'Teppichreinigung [Stadt]', 'Allergikerfreundlich' und 'Raumklima verbessern'. Der Beitrag soll informativ sein und unsere Expertise unterstreichen. Zielgruppe: Privatkunden und Büros in [Stadt/Region]."

*   "Du bist ein Werbetexter. Entwickle zwei kurze Slogans (jeweils max. 10 Wörter) für unsere Reinigungsfirma, die unsere Zuverlässigkeit und Gründlichkeit betonen. Die Slogans sollen leicht merkbar sein und unsere Marke positiv repräsentieren. Zielgruppe: Alle potenziellen Kunden."

*   "Du bist ein Social-Media-Manager. Erstelle 3 Ideen für kurze Video-Stories (jeweils max. 15 Sekunden) für [Plattform, z.B. TikTok oder Instagram Reels], die einen 'Vorher-Nachher'-Effekt unserer Reinigungsarbeiten zeigen. Beschreibe kurz den Inhalt und den Call-to-Action für jede Story. Zielgruppe: Privatkunden, die schnelle Ergebnisse schätzen."

*   "Du bist ein Kundenservice-Spezialist. Formuliere eine höfliche und professionelle Antwort auf eine negative Online-Bewertung, in der ein Kunde die Pünktlichkeit unserer Reinigungskräfte kritisiert. Zeige Verständnis, entschuldige dich und biete eine Lösung oder weitere Kontaktaufnahme an. Die Antwort soll unsere Professionalität unterstreichen. Zielgruppe: Der unzufriedene Kunde und zukünftige Interessenten."
