# Umsetz-Checkliste — KI im Alltag

- [ ] Ein wiederkehrendes Schreib-Problem auswählen (z. B. Angebote, Mails).
- [ ] Einen Prompt aus dem Paket anpassen und 1 Woche täglich nutzen.
- [ ] Ergebnisse immer gegenlesen — Fakten/Zahlen kommen von dir.
- [ ] Für Sensibles nur Tools mit klarer EU-Datenverarbeitung.
- [ ] Was gut lief, als Vorlage speichern. Was nicht, weglassen.
