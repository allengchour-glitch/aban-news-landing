**Results must always be reviewed and edited for accuracy and brand voice.**

* "Generate 5 unique, [cuisine type] appetizer descriptions (20-30 words each) for our new spring menu, highlighting [key ingredient 1] and [key ingredient 2]. Focus on [flavor profile, e.g., fresh, vibrant, comforting]."
* "Write a social media post (Twitter, 150 characters max) announcing our new [seasonal dish name] featuring [main ingredient]. Include a call to action to [visit our website/make a reservation]."
* "Develop 3 compelling email subject lines for a newsletter promoting our upcoming [event type, e.g., wine tasting, chef's table]. Aim for high open rates and mention [unique selling point, e.g., limited seats, special guest]."
* "Create a short, engaging script (30 seconds) for an Instagram Reel showcasing the preparation of our [signature dish]. Focus on [visual appeal, key steps, tantalizing sounds]."
* "Draft a response to a positive online review (Google/Yelp) for [restaurant name] that mentions [specific dish/service]. Express gratitude and encourage a return visit."
* "List 4 innovative ideas for [restaurant type, e.g., fine dining, casual bistro] to reduce food waste in the kitchen, specifically focusing on [ingredient category, e.g., vegetables, bread]."
