**Wichtiger Hinweis:** Die Ergebnisse der KI sind Vorschläge und müssen immer kritisch geprüft und an die individuellen Bedürfnisse angepasst werden. Sie können als Inspiration dienen, ersetzen aber nicht die eigene Expertise.

Hier sind 6 erprobte, konkrete KI-Prompts für Handwerker (DACH):

*   "Ich brauche 3 überzeugende Social-Media-Posts für [Plattform, z.B. Instagram] für mein Handwerksunternehmen [Name des Unternehmens]. Das Thema ist [Thema, z.B. "Vorteile einer professionellen Badsanierung"]. Die Posts sollen [Zielgruppe, z.B. Hausbesitzer in den 40ern] ansprechen und sie dazu ermutigen, [gewünschte Aktion, z.B. einen kostenlosen Beratungstermin zu vereinbaren]. Verwende eine [gewünschte Tonalität, z.B. freundliche und informative] Sprache. Füge relevante Emojis und Hashtags hinzu."

*   "Erstelle einen Entwurf für eine E-Mail an einen potenziellen Neukunden, der sich über [Dienstleistung, z.B. Dachreparatur] erkundigt hat. Die E-Mail soll [wichtige Informationen, z.B. unsere Expertise, ein unverbindliches Angebot, nächste Schritte] enthalten. Betone unsere [Alleinstellungsmerkmale, z.B. schnelle Reaktionszeit, hochwertige Materialien]. Die Tonalität soll [gewünschte Tonalität, z.B. professionell und vertrauenswürdig] sein. Füge einen klaren Call-to-Action hinzu."

*   "Ich benötige eine kurze, prägnante Beschreibung für meine Website-Startseite, die mein Handwerksunternehmen [Name des Unternehmens] und unsere Kernkompetenzen in [Branche, z.B. Elektrotechnik] vorstellt. Die Beschreibung soll [Zielgruppe, z.B. Geschäftskunden] ansprechen und unser Engagement für [wichtiger Wert, z.B. Qualität und Zuverlässigkeit] hervorheben. Die Länge sollte maximal [Anzahl] Wörter betragen."

*   "Schreibe einen Blogbeitrag zum Thema '[Thema, z.B. "Die häufigsten Fehler bei der Gartenplanung und wie man sie vermeidet"]' für meine Website. Der Beitrag soll [Zielgruppe, z.B. Hobbygärtner] informieren und ihnen praktische Tipps geben. Integriere [Schlüsselwörter, z.B. "Gartenpflege", "Landschaftsbau"] auf natürliche Weise. Der Beitrag sollte eine [gewünschte Tonalität, z.B. hilfreiche und zugängliche] Sprache verwenden und etwa [Anzahl] Wörter umfassen."

*   "Entwickle 5 Fragen für ein Interview mit einem zufriedenen Kunden, um eine Testimonial-Video aufzunehmen. Die Fragen sollen [Aspekte, die hervorgehoben werden sollen, z.B. die Qualität unserer Arbeit, den Kundenservice, die pünktliche Fertigstellung] beleuchten. Ziel ist es, authentische und überzeugende Antworten zu erhalten, die andere potenzielle Kunden ansprechen."

*   "Formuliere eine Antwort auf eine negative Online-Bewertung, die besagt, dass '[konkrete Kritik, z.B. "die Kommunikation schlecht war"]'. Die Antwort soll [gewünschte Tonalität, z.B. professionell, entschuldigend, lösungsorientiert] sein. Biete an, die Situation [nächste Schritte, z.B. persönlich zu besprechen oder eine Lösung zu finden]. Zeige Verständnis für die Kritik, ohne die Schuld komplett auf uns zu nehmen."
