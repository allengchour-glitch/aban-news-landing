**Wichtiger Hinweis:** Die Ergebnisse der KI sollten immer sorgfältig geprüft und an die individuellen Bedürfnisse angepasst werden!

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Handwerker (DACH):

* "Ich brauche einen Entwurf für einen kurzen, prägnanten Social Media Post (Instagram/Facebook) für mein Handwerksunternehmen [Name des Unternehmens]. Wir bieten [spezifische Dienstleistung, z.B. Badsanierung, Dachreparatur, Maßanfertigungen] an. Der Post soll potenzielle Kunden in [Region/Stadt] ansprechen und sie dazu ermutigen, uns für ein unverbindliches Angebot zu kontaktieren. Füge einen Call-to-Action hinzu und schlage passende Hashtags vor."

* "Erstelle mir einen Textentwurf für eine E-Mail an einen potenziellen Neukunden, der sich über unsere [spezifische Dienstleistung] informiert hat. Die E-Mail soll freundlich und professionell sein, die Vorteile unserer Dienstleistung kurz hervorheben und einen Termin für ein persönliches Beratungsgespräch vorschlagen. Füge eine Möglichkeit zur Kontaktaufnahme hinzu."

* "Formuliere drei verschiedene Überschriften für einen Blogbeitrag auf meiner Website zum Thema '[Problem, das du für Kunden löst, z.B. "Wie Sie Schimmel in Ihrem Bad dauerhaft loswerden"]'. Die Überschriften sollen neugierig machen und zum Weiterlesen anregen, ohne reißerisch zu wirken."

* "Ich benötige Hilfe bei der Formulierung einer kurzen, aber überzeugenden 'Über uns'-Sektion für meine Website. Mein Unternehmen [Name des Unternehmens] ist spezialisiert auf [Deine Spezialisierung, z.B. hochwertige Holzmöbel nach Maß, energieeffiziente Heizungssysteme]. Betone unsere Werte wie [zwei bis drei Werte, z.B. Qualität, Zuverlässigkeit, Kundennähe] und unsere langjährige Erfahrung in [Anzahl] Jahren."

* "Schreibe mir einen Entwurf für eine Antwort auf eine positive Online-Bewertung (z.B. Google My Business) für mein Handwerksunternehmen [Name des Unternehmens]. Der Kunde lobt [spezifischer Aspekt, z.B. die schnelle Ausführung, die Freundlichkeit der Mitarbeiter, das Endergebnis]. Die Antwort soll sich bedanken, die Wertschätzung ausdrücken und die positive Erfahrung bestätigen."

* "Ich suche nach Ideen für eine kurze Checkliste oder einen Ratgeber, den ich meinen Kunden als Download auf meiner Website anbieten kann. Das Thema soll '[Thema, das für deine Kunden relevant ist, z.B. "Worauf Sie bei der Auswahl eines neuen Daches achten sollten", "Pflegehinweise für Ihre neuen Holzdielen"]' sein. Liste mir 5-7 Punkte auf, die für den Laien verständlich und hilfreich sind."
