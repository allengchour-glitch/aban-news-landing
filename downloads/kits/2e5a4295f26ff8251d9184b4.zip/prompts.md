**Wichtiger Hinweis:** Die Ergebnisse der KI müssen immer kritisch geprüft und an die spezifischen Gegebenheiten Ihres Handwerksbetriebs angepasst werden. Die KI ist ein Werkzeug, kein Ersatz für Fachwissen und Erfahrung.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Handwerker (DACH):

* "Ich benötige 5-7 überzeugende Argumente, warum ein Kunde sich für [Ihre Dienstleistung/Ihr Produkt, z.B. eine energetische Sanierung, maßgefertigte Möbel, eine Dachreparatur] von meinem Handwerksbetrieb entscheiden sollte. Berücksichtige dabei die Vorteile von [einem spezifischen Merkmal Ihres Betriebs, z.B. unserer regionalen Nähe, unserer langjährigen Erfahrung, unserer Spezialisierung auf umweltfreundliche Materialien]."

* "Formuliere einen kurzen, prägnanten Text (max. 100 Wörter) für unsere Website-Startseite, der [Ihre Zielgruppe, z.B. Hausbesitzer in der Region XY, Unternehmen mit Bedarf an speziellen Installationen] direkt anspricht und das Hauptproblem löst, das wir mit [Ihrer Kernleistung, z.B. effizienten Heizlösungen, individuellen Badgestaltungen] beheben. Füge einen klaren Call-to-Action hinzu, z.B. 'Jetzt unverbindliches Angebot anfordern'."

* "Erstelle eine Liste von 3-5 häufig gestellten Fragen (FAQs) zu [Ihrem Handwerk/Ihrer Dienstleistung, z.B. der Installation von Photovoltaikanlagen, der Renovierung von Altbauten]. Gib für jede Frage eine kurze, verständliche Antwort, die potenzielle Kunden aufklärt und Vertrauen schafft. Vermeide Fachjargon, wo immer möglich."

* "Ich brauche Ideen für 3-4 Social-Media-Posts (z.B. für Facebook oder Instagram), die das Thema [ein aktuelles Thema in Ihrem Handwerk, z.B. Energieeffizienz, Smart Home, nachhaltige Materialien] aufgreifen. Jeder Post sollte einen Mehrwert für meine Follower bieten, z.B. einen Tipp, einen Einblick hinter die Kulissen oder eine kurze Erklärung. Füge passende Hashtags hinzu, die für [Ihre Region/Ihr Handwerk] relevant sind."

* "Schreibe einen kurzen E-Mail-Text (ca. 150-200 Wörter) für Bestandskunden, in dem ich sie über [eine neue Dienstleistung, ein saisonales Angebot, eine wichtige Information, z.B. Wartungstipps für den Winter] informiere. Der Ton soll persönlich und wertschätzend sein. Integriere einen klaren Vorteil für den Kunden und einen Link zu weiteren Informationen auf unserer Website."

* "Entwickle einen kurzen Slogan (max. 10 Wörter) für meinen Handwerksbetrieb, der [Ihre Kernkompetenz, z.B. Präzision und Zuverlässigkeit, kreative Lösungen, schnelle und saubere Ausführung] hervorhebt und gleichzeitig [Ihre Branche, z.B. Sanitär, Tischlerei, Elektroinstallation] klar kommuniziert. Gib mir 3-5 verschiedene Optionen zur Auswahl."
