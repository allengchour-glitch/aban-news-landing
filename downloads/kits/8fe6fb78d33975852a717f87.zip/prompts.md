Bitte beachte, dass die Ergebnisse dieser KI-Prompts immer sorgfältig geprüft und auf ihre rechtliche Korrektheit und Anwendbarkeit hin überprüft werden müssen. Sie dienen als Ausgangspunkt und Unterstützung, ersetzen aber keine juristische Expertise.

*   "Erstelle eine erste Entwurfsversion eines Schriftsatzes für eine [Klageart, z.B. Mietminderung, Schadensersatzforderung] im Fall [kurze Falldarstellung, z.B. Mieter M. mindert Miete wegen Schimmelbefalls]. Berücksichtige dabei die relevanten Paragraphen des [Gesetzes, z.B. BGB] und die aktuelle Rechtsprechung zum Thema [Thema, z.B. Schimmel als Mietmangel]. Füge Platzhalter für konkrete Daten und Beweismittel ein."

*   "Analysiere den vorliegenden Vertrag zwischen [Partei A] und [Partei B] vom [Datum des Vertrags] bezüglich [Vertragsgegenstand]. Identifiziere potenzielle Risikoklauseln für [Deine Mandantschaft, z.B. den Käufer] und schlage Formulierungen vor, die diese Risiken minimieren könnten. Konzentriere dich dabei auf [spezifischer Aspekt, z.B. Haftungsbeschränkungen, Kündigungsfristen]."

*   "Fasse die wichtigsten Argumente und Entscheidungsgründe des Urteils des [Gerichts, z.B. BGH] vom [Datum des Urteils] zum Aktenzeichen [Aktenzeichen] zusammen. Erläutere, welche Implikationen dieses Urteil für unseren Fall [kurze Falldarstellung, z.B. ähnlicher Sachverhalt in einem laufenden Verfahren] haben könnte."

*   "Formuliere eine E-Mail an die Gegenpartei [Name der Gegenpartei/Anwaltskanzlei] bezüglich [Streitgegenstand, z.B. einer ausstehenden Zahlung]. Drücke unsere Forderung klar aus, setze eine angemessene Frist zur Erfüllung und weise auf die möglichen rechtlichen Konsequenzen bei Nichteinhaltung hin. Halte den Ton professionell und sachlich."

*   "Erstelle eine Liste von Fragen, die ich meinem Mandanten [Name des Mandanten] im Rahmen der Erstberatung zu einem [Rechtsgebiet, z.B. Arbeitsrechtlichen Kündigungsfall] stellen sollte. Die Fragen sollen darauf abzielen, alle relevanten Fakten zu sammeln, die für die Einschätzung des Falls und die weitere Vorgehensweise entscheidend sind."

*   "Recherchiere die aktuelle Gesetzeslage und relevante Rechtsprechung zum Thema [spezifisches rechtliches Problem, z.B. Datenschutz bei Mitarbeiterüberwachung] in [Land, z.B. Deutschland, Österreich, Schweiz]. Fasse die wesentlichen Punkte zusammen und identifiziere potenzielle Fallstricke für Unternehmen, die solche Maßnahmen ergreifen möchten."
