**Wichtiger Hinweis:** Die Ergebnisse dieser KI-Prompts sind als Entwürfe zu verstehen und müssen stets von einem Juristen sorgfältig geprüft und angepasst werden. Die KI kann keine Rechtsberatung ersetzen.

Hier sind 6 erprobte, konkrete KI-Prompts für Anwälte (DACH):

* "Erstelle einen Entwurf für ein Mandantenschreiben, in dem du [Mandant_Name] über den aktuellen Stand seines Falles bezüglich [Rechtsgebiet/Sachverhalt] informierst. Erkläre die nächsten Schritte und die voraussichtliche Dauer des Verfahrens. Füge eine Aufforderung zur Bereitstellung von [fehlende_Unterlagen/Informationen] bis zum [Datum] hinzu."

* "Analysiere den vorliegenden Vertrag zwischen [Partei_A] und [Partei_B] vom [Datum] im Hinblick auf potenzielle Risiken und ungünstige Klauseln für [Mandant_Name]. Identifiziere insbesondere Klauseln zu [spezifische_Klausel_Art, z.B. Haftungsausschluss, Kündigungsfristen] und schlage mögliche Formulierungen zur Verbesserung vor."

* "Fasse die wesentlichen Argumente und rechtlichen Grundlagen für eine Klage im Fall von [Sachverhalt] gegen [Gegner_Name] zusammen. Berücksichtige dabei die aktuelle Rechtsprechung zu [relevantem_Gesetz/Paragraphen] und nenne mindestens drei relevante Urteile oder Kommentare, die unsere Position stärken."

* "Erstelle eine Liste von Fragen für ein Erstgespräch mit einem Mandanten, der wegen [Rechtsgebiet/Sachverhalt] rechtlichen Beistand sucht. Die Fragen sollen darauf abzielen, alle relevanten Informationen zu sammeln, um eine erste Einschätzung des Falles vornehmen zu können und den weiteren Beratungsbedarf zu klären."

* "Formuliere einen Widerspruch gegen einen behördlichen Bescheid vom [Datum] der [Behörde] bezüglich [Sachverhalt]. Begründe den Widerspruch mit [konkrete_Begründung, z.B. fehlende Rechtsgrundlage, fehlerhafte Sachverhaltsdarstellung] und fordere die Aufhebung des Bescheids."

* "Entwickle einen Entwurf für eine E-Mail an [Kollege_Name] mit der Bitte um eine Einschätzung zu einem komplexen Fall im Bereich [Rechtsgebiet]. Beschreibe den Sachverhalt kurz und prägnant und stelle konkrete Fragen zu [spezifische_Rechtsfrage/Problemstellung], bei denen du eine zweite Meinung benötigst."
