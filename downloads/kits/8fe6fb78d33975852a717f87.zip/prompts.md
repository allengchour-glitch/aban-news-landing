**Wichtiger Hinweis:** Die Ergebnisse der KI-Prompts müssen stets sorgfältig geprüft und auf ihre Richtigkeit und Vollständigkeit hin kontrolliert werden. Die KI ist ein Werkzeug, kein Ersatz für juristische Expertise.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Anwälte (DACH):

*   "Ich benötige eine Zusammenfassung der aktuellen Rechtsprechung des [Gericht, z.B. BGH] zum Thema [Rechtsgebiet, z.B. Mietminderung wegen Schimmel]. Bitte konzentriere dich auf die wesentlichen Entscheidungsgründe und Leitsätze der letzten [Zeitraum, z.B. 3 Jahre]."

*   "Erstelle mir einen Entwurf für ein Mandantenschreiben, in dem ich [Mandantennamen] über den aktuellen Stand seines Falls [Aktenzeichen/Fallbezeichnung] informiere. Erläutere dabei die nächsten Schritte, insbesondere [konkrete Schritte, z.B. die Frist zur Klageerwiderung] und bitte um [gewünschte Aktion des Mandanten, z.B. die Bereitstellung weiterer Unterlagen]."

*   "Analysiere den vorliegenden Vertrag [Vertragsart, z.B. Kaufvertrag] zwischen [Partei A] und [Partei B] und identifiziere potenzielle Risikoklauseln für [Deine Mandantenpartei]. Bitte markiere insbesondere Klauseln, die [spezifisches Problem, z.B. eine einseitige Kündigungsmöglichkeit] ermöglichen könnten und schlage alternative Formulierungen vor."

*   "Fasse die relevanten Fakten aus dem beigefügten Schriftsatz des Gegners vom [Datum] zusammen. Identifiziere dabei die Hauptargumente der Gegenseite und die Punkte, die wir in unserer Erwiderung besonders adressieren müssen. Bitte gib auch an, welche Anlagen der Gegenseite besonders relevant sind."

*   "Ich brauche eine Liste von Argumenten und rechtlichen Grundlagen, um die Forderung von [Gegner] auf [Forderung, z.B. Schadensersatz in Höhe von X Euro] abzuwehren. Der Sachverhalt ist, dass [kurze Sachverhaltsbeschreibung]. Berücksichtige dabei insbesondere [relevante Gesetze/Paragraphen, z.B. § 823 BGB, § 249 BGB]."

*   "Formuliere eine Anfrage an das [Behörde/Gericht, z.B. Grundbuchamt] bezüglich [konkrete Auskunft, z.B. der aktuellen Eigentumsverhältnisse des Grundstücks Flurstück X, Gemarkung Y]. Bitte gib an, welche Informationen für die Anfrage zwingend erforderlich sind und welche Gebühren voraussichtlich anfallen könnten."
