Absolut! Hier sind 6 erprobte, konkrete KI-Prompts für die Gastronomie (DACH) in der Du-Form. Denk daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen.

*   "Erstelle 5 Social Media Posts für unser Restaurant [Name des Restaurants], die unsere [Spezialität/Besonderheit] hervorheben. Zielgruppe sind [Zielgruppe, z.B. junge Paare, Familien mit Kindern]. Verwende einen [Tonfall, z.B. humorvollen, eleganten] Ton und füge passende Emojis hinzu. Füge einen Call-to-Action ein, der zur [Reservierung/Bestellung] aufruft."

*   "Schreibe einen kurzen, ansprechenden Text für unsere Website-Startseite, der neue Gäste dazu einlädt, unser [Konzept, z.B. gemütliches Café, modernes Bistro] zu entdecken. Betone unsere [Alleinstellungsmerkmale, z.B. regionale Zutaten, hausgemachte Kuchen, besondere Atmosphäre]. Der Text sollte nicht länger als 100 Wörter sein."

*   "Entwickle 3 Ideen für eine saisonale Sonderkarte im [Monat/Jahreszeit]. Jede Idee sollte ein Hauptgericht, eine Vorspeise und ein Dessert umfassen, die zu [Thema/Zutat, z.B. Spargel, Herbst, Weihnachten] passen. Gib auch eine kurze Begründung für die Auswahl der Gerichte."

*   "Formuliere eine Antwort auf eine 4-Sterne-Bewertung auf [Plattform, z.B. Google, TripAdvisor], die unser [Gericht/Service] lobt, aber einen kleinen Kritikpunkt bezüglich [Kritikpunkt, z.B. Wartezeit, Lautstärke] enthält. Bedanke dich für das positive Feedback und gehe konstruktiv auf den Kritikpunkt ein, um zu zeigen, dass wir uns verbessern wollen."

*   "Erstelle eine kurze E-Mail für unsere Newsletter-Abonnenten, die sie über [Anlass, z.B. ein bevorstehendes Event, eine neue Speisekarte, eine Aktion] informiert. Der Betreff sollte neugierig machen und der Inhalt sollte einen klaren Call-to-Action enthalten, z.B. 'Jetzt reservieren' oder 'Mehr erfahren'."

*   "Schreibe einen kurzen Text für eine Stellenanzeige, um einen [Position, z.B. Koch, Servicekraft, Barista] für unser Team zu finden. Beschreibe die wichtigsten Aufgaben und die gewünschten Qualifikationen. Betone die Vorteile der Arbeit bei uns, z.B. [Vorteile, z.B. gutes Teamklima, flexible Arbeitszeiten, Entwicklungsmöglichkeiten]."
