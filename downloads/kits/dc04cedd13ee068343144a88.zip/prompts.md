Gerne, hier sind 6 erprobte, konkrete KI-Prompts für die Gastronomie (DACH), die du direkt verwenden kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen.

*   "Entwickle 5 kreative Social Media Post-Ideen für unser [Restaurantname] in [Stadt], um unser neues [Saisonales Gericht/Getränk] zu bewerben. Die Posts sollen unsere Zielgruppe von [Altersgruppe] ansprechen und einen Call-to-Action enthalten, der auf unsere [Website/Reservierungslink] verweist. Verwende einen [humorvollen/eleganten/bodenständigen] Ton."

*   "Schreibe einen kurzen, ansprechenden Text für unsere Speisekarte, der unser [Besonderes Gericht, z.B. "Hausgemachte Spätzle mit Pilzrahmsoße"] beschreibt. Hebe dabei die [Qualität der Zutaten/regionale Herkunft/besondere Zubereitung] hervor und wecke die Neugier unserer Gäste. Der Text sollte maximal [Anzahl] Wörter lang sein."

*   "Formuliere eine E-Mail für unsere Newsletter-Abonnenten, um sie über unsere bevorstehende [Veranstaltung, z.B. "Weinprobe" oder "Themenabend"] am [Datum] zu informieren. Beschreibe kurz das Highlight der Veranstaltung, nenne den Preis von [Preis] pro Person und fordere zur Reservierung über [Reservierungslink] auf. Der Betreff sollte neugierig machen."

*   "Erstelle 3 Vorschläge für eine Antwort auf eine positive Online-Bewertung auf [Plattform, z.B. Google/TripAdvisor]. Die Antworten sollen persönlich klingen, sich auf das genannte Lob beziehen (z.B. "Service" oder "Atmosphäre") und sich bei dem Gast bedanken. Vermeide Standardfloskeln."

*   "Entwickle eine kurze Stellenanzeige für eine/n [Position, z.B. "Servicekraft in Teilzeit"] für unser [Restaurantname] in [Stadt]. Beschreibe die wichtigsten Aufgaben, die gewünschten Eigenschaften (z.B. "Teamfähigkeit", "Erfahrung im Service") und biete einen Anreiz (z.B. "familiäres Team", "flexible Arbeitszeiten"). Gib an, wie man sich bewerben kann ([E-Mail-Adresse/Telefonnummer])."

*   "Brainstorme 5 Ideen für eine Marketingkampagne, um unser [Catering-Service/Mittagsmenü] in [Stadt/Region] bekannter zu machen. Die Ideen sollen kostengünstig sein und auf unsere Zielgruppe von [Firmenkunden/Büroangestellten/Familien] abzielen. Nenne konkrete Kanäle (z.B. Social Media, lokale Zeitungen, Kooperationen)."
