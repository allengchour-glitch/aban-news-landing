Hier sind 6 erprobte KI-Prompts für die Gastronomie (DACH), die du direkt verwenden kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen.

*   "Erstelle 5 kreative Social Media Posts für unser [Restaurantname] auf Instagram, um unsere neue [Saisonale Speise/Getränk] zu bewerben. Fokus auf ansprechende Beschreibungen, die Lust auf einen Besuch machen. Verwende Hashtags wie # [Stadt] # [Restaurantname] # [Saison] und einen Call-to-Action, der zur Tischreservierung aufruft."

*   "Entwickle eine kurze, einladende E-Mail für unsere Newsletter-Abonnenten, die sie über unsere bevorstehende [Veranstaltung/Themenabend] informiert. Beschreibe die Highlights, nenne das Datum und die Uhrzeit und füge einen Link zur Online-Reservierung hinzu. Betone den Mehrwert für unsere Gäste."

*   "Schreibe 3 Vorschläge für eine kurze und prägnante Beschreibung unseres [Restaurantname] für Online-Verzeichnisse wie Google My Business oder TripAdvisor. Betone unsere [Alleinstellungsmerkmale, z.B. regionale Küche, gemütliches Ambiente, besondere Weinauswahl] und unsere Lage in [Stadt/Viertel]."

*   "Formuliere eine Antwort auf eine positive Online-Bewertung, die unser [Gericht/Service] lobt. Bedanke dich herzlich, erwähne das gelobte Detail und drücke die Hoffnung aus, den Gast bald wieder begrüßen zu dürfen. Bleibe authentisch und persönlich."

*   "Erstelle eine Liste mit 10 Fragen, die wir unseren Gästen in einer kurzen Umfrage stellen könnten, um Feedback zu unserem [Service/Speisekarte/Atmosphäre] zu erhalten. Die Fragen sollen offen sein und uns helfen, Verbesserungspotenziale zu identifizieren, ohne zu aufdringlich zu wirken."

*   "Schreibe einen kurzen Text für eine Anzeige (z.B. für lokale Zeitungen oder Online-Portale), die auf unsere [Mittagsangebote/Happy Hour/Abendkarte] aufmerksam macht. Nenne die wichtigsten Vorteile für den Gast und füge unsere Adresse und Website hinzu. Der Ton soll einladend und direkt sein."
