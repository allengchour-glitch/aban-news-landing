**Wichtiger Hinweis:** Die Ergebnisse der KI sollten stets kritisch geprüft und mit den geltenden Gesetzen und Richtlinien abgeglichen werden. Sie dienen als Unterstützung, nicht als Ersatz für professionelle Steuerberatung.

Hier sind 6 erprobte, konkrete KI-Prompts für Steuerberater (DACH):

*   "Ich brauche eine detaillierte Zusammenfassung der aktuellen Änderungen im Einkommensteuergesetz für das Veranlagungsjahr [aktuelles Jahr] in Deutschland, die für selbstständige IT-Berater relevant sind. Bitte konzentriere dich auf [spezifische Bereiche, z.B. Abschreibungsmöglichkeiten, Homeoffice-Regelungen, neue Freibeträge]."

*   "Erstelle mir einen Entwurf für einen Widerspruch gegen einen Steuerbescheid des Finanzamtes [Name des Finanzamtes] für meinen Mandanten [Name des Mandanten], Steuernummer [Steuernummer]. Der Widerspruch soll sich auf die Nichtanerkennung von [konkreter Sachverhalt, z.B. Reisekosten, Bewirtungskosten] in Höhe von [Betrag] Euro beziehen und die Argumentation auf Basis von [relevante Paragraphen, Urteile] aufbauen."

*   "Analysiere die steuerlichen Auswirkungen einer geplanten Umwandlung eines Einzelunternehmens in eine GmbH in Österreich für meinen Mandanten [Name des Mandanten]. Berücksichtige dabei die Aspekte [konkrete Aspekte, z.B. Grunderwerbsteuer, Kapitalertragsteuer, Haftungsfragen] und gib eine Empfehlung für die optimale Vorgehensweise."

*   "Fasse die wichtigsten steuerlichen Pflichten und Fristen für einen neu gegründeten Verein in der Schweiz (Kanton [Kanton]) zusammen, der gemeinnützige Zwecke verfolgt. Gehe insbesondere auf die Anforderungen an die Buchführung und die Möglichkeiten der Steuerbefreiung ein."

*   "Ich habe eine Anfrage von einem Mandanten bezüglich der steuerlichen Behandlung von Kryptowährungen in Deutschland. Bitte erstelle eine Übersicht über die aktuellen Regelungen zur Besteuerung von Gewinnen aus dem Handel mit [spezifische Kryptowährung, z.B. Bitcoin, Ethereum] und gib Hinweise zur Dokumentationspflicht."

*   "Formuliere eine E-Mail an einen Mandanten, der eine Photovoltaikanlage auf seinem privaten Wohnhaus installiert hat. Erkläre ihm die steuerlichen Auswirkungen der Einspeisung von Strom ins Netz und die Option der Kleinunternehmerregelung. Gehe dabei auf die Vorteile und Nachteile der jeweiligen Optionen ein."
