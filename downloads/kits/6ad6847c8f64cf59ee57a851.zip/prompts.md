**Important Note:** AI-generated content should always be carefully reviewed and fact-checked by a medical professional before use in any patient communication or public-facing materials.

Here are 6 proven, concrete copy-paste AI prompts for Ärzte:

*   "Generate a concise, patient-friendly explanation of [medical condition, e.g., Type 2 Diabetes] for a patient information leaflet. Focus on causes, common symptoms, and basic management strategies. Use language understandable by a layperson with no medical background. Avoid jargon."

*   "Draft a professional email to a colleague, Dr. [Colleague's Last Name], requesting a referral for patient [Patient's Initials] for [specialty, e.g., cardiology consultation]. Briefly outline the patient's primary symptoms and relevant medical history, and attach [relevant document, e.g., recent ECG results]."

*   "Create a social media post (Facebook/Instagram) for our practice announcing [new service, e.g., extended evening hours]. Include details about the benefit to patients, how to book an appointment, and a call to action. Use a friendly and informative tone."

*   "Summarize the key findings and recommendations from the clinical guideline [Guideline Name/Organization, e.g., NICE Guideline for Hypertension] regarding [specific aspect, e.g., first-line pharmacological treatment options]. Present the information in bullet points for quick reference."

*   "Write a short, empathetic message for a patient who has just received a [diagnosis, e.g., chronic pain diagnosis]. Focus on acknowledging their feelings, offering support, and outlining the next steps in their treatment plan. Emphasize that they are not alone."

*   "Develop three distinct headline options for a blog post discussing [topic, e.g., the importance of regular health check-ups]. Each headline should be engaging, informative, and target a general audience. Aim for a mix of direct and benefit-oriented approaches."
