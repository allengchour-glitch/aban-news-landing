**Important Note:** AI-generated content should always be reviewed and edited by a human to ensure accuracy, tone, and brand consistency.

Here are 6 proven, concrete copy-paste AI prompts for Handwerker (tradespeople):

*   "Erstelle 3 kurze, überzeugende Social-Media-Posts für [Art des Handwerks, z.B. Sanitärinstallationen], die potenzielle Kunden in [Stadt/Region] dazu anregen, einen kostenlosen Kostenvoranschlag anzufordern. Fokus auf [Vorteil, z.B. schnelle Problemlösung, Energieeffizienz, moderne Designs]."

*   "Schreibe einen Entwurf für eine E-Mail an einen Kunden, der kürzlich einen Auftrag für [Art der Dienstleistung, z.B. Küchenrenovierung] bei uns abgeschlossen hat. Die E-Mail soll sich für das Vertrauen bedanken, um eine kurze Online-Bewertung bitten (mit Link zu [Bewertungsplattform, z.B. Google My Business]) und auf unser Angebot für [zukünftige Dienstleistung, z.B. jährliche Wartung] hinweisen."

*   "Formuliere eine kurze, prägnante Antwort auf eine häufig gestellte Frage auf unserer Website: 'Wie lange dauert es, bis Sie mit der Arbeit an [Art des Projekts, z.B. einer Badsanierung] beginnen können?' Die Antwort sollte unsere durchschnittliche Vorlaufzeit von [Anzahl] Wochen nennen und darauf hinweisen, dass dies je nach Auftragslage variieren kann."

*   "Entwickle 4 Stichpunkte für eine 'Über uns'-Sektion auf unserer Website, die unsere Kernwerte als Handwerksbetrieb für [Art des Handwerks, z.B. Dachdeckerei] hervorheben. Konzentriere dich auf [Wert 1, z.B. Qualität], [Wert 2, z.B. Zuverlässigkeit], [Wert 3, z.B. Kundenzufriedenheit] und [Wert 4, z.B. lokale Verbundenheit]."

*   "Schreibe einen kurzen Text für eine Anzeige in einem lokalen [Medium, z.B. Wochenblatt] für unsere Dienstleistungen im Bereich [Art des Handwerks, z.B. Heizungsinstallation]. Die Anzeige soll einen klaren Call-to-Action enthalten: 'Rufen Sie uns noch heute an für eine unverbindliche Beratung unter [Telefonnummer]'."

*   "Erstelle eine Liste von 5 Fragen, die wir potenziellen Kunden bei einem Erstgespräch für [Art des Projekts, z.B. eine Elektroinstallation] stellen sollten, um deren Bedürfnisse und Erwartungen besser zu verstehen. Die Fragen sollen Informationen zu [Aspekt 1, z.B. Budget], [Aspekt 2, z.B. Zeitrahmen], [Aspekt 3, z.B. spezifische Anforderungen], [Aspekt 4, z.B. bestehende Probleme] und [Aspekt 5, z.B. gewünschtes Ergebnis] abdecken."
