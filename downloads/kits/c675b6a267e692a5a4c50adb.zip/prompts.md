Hier sind 6 erprobte, konkrete KI-Prompts für Architekten (DACH), die du direkt kopieren und anpassen kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und als Ausgangspunkt für deine eigene Expertise zu nutzen.

---

*   "Ich benötige eine detaillierte **Checkliste für die Genehmigungsplanung eines Mehrfamilienhauses** in [Bundesland, z.B. Bayern] mit [Anzahl] Wohneinheiten. Berücksichtige dabei typische Anforderungen der [Landesbauordnung, z.B. BayBO] und gängige baurechtliche Vorschriften für [spezifische Nutzung, z.B. Wohnen mit Tiefgarage]. Füge auch Punkte hinzu, die oft vergessen werden, wie z.B. [Beispiel: Stellplatznachweis für Fahrräder]."

*   "Entwickle mir drei **konzeptionelle Entwurfsideen für ein Einfamilienhaus** auf einem [Grundstücksgröße, z.B. 800m²] großen Grundstück in [Topographie, z.B. Hanglage] mit [Himmelsrichtung] Ausrichtung. Der Entwurf soll [Stilrichtung, z.B. modern-minimalistisch] sein und [Anzahl] Personen beherbergen. Wichtige Anforderungen sind [Anforderung 1, z.B. offener Wohn-Essbereich], [Anforderung 2, z.B. direkter Gartenzugang von der Küche] und [Anforderung 3, z.B. Home-Office-Bereich]. Visualisiere die Ideen kurz in Textform."

*   "Formuliere einen **E-Mail-Entwurf für eine erste Kontaktaufnahme mit einem potenziellen Neukunden**, der sich für den Umbau einer [Gebäudetyp, z.B. denkmalgeschützten Scheune] zu Wohnzwecken interessiert. Betone unsere Expertise in [Spezialgebiet, z.B. Bestandssanierung und Denkmalpflege] und schlage ein unverbindliches Erstgespräch vor. Füge einen Call-to-Action hinzu."

*   "Erstelle eine **Liste von relevanten Förderprogrammen und Zuschüssen für energieeffizientes Bauen und Sanieren** in [Land, z.B. Deutschland] für private Bauherren. Konzentriere dich auf Programme, die [spezifische Maßnahmen, z.B. Wärmepumpeninstallation und Fassadendämmung] unterstützen. Gib auch die zuständigen Stellen oder Webseiten an, wo weitere Informationen gefunden werden können."

*   "Ich brauche eine **Argumentationshilfe für ein Kundengespräch**, in dem ich die Vorteile einer [spezifische Bauweise, z.B. Holzrahmenbauweise] gegenüber einer [alternative Bauweise, z.B. Massivbauweise] darlegen möchte. Konzentriere dich auf Aspekte wie [Vorteil 1, z.B. kürzere Bauzeit], [Vorteil 2, z.B. ökologische Nachhaltigkeit] und [Vorteil 3, z.B. Raumklima]. Nenne auch mögliche Einwände des Kunden und wie ich darauf reagieren kann."

*   "Verfasse eine **Stellenanzeige für eine/n Architekt/in (m/w/d) mit Schwerpunkt Ausführungsplanung** für unser Büro in [Stadt, z.B. Hamburg]. Wir suchen jemanden mit [Anzahl] Jahren Berufserfahrung und fundierten Kenntnissen in [Software, z.B. Revit und AutoCAD]. Beschreibe die Hauptaufgaben und unser Teamklima. Füge auch die erforderlichen Qualifikationen und Benefits hinzu."
