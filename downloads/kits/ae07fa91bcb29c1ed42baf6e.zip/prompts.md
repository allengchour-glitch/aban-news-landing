**Important Note:** Always review and refine the AI's output for accuracy, tone, and suitability before use. AI is a tool, not a replacement for human expertise.

*   "Develop three unique, engaging social media captions (under 150 characters each) for our new [seasonal dish/cocktail]. Focus on sensory descriptions and include a call to action to [visit our website/book a table]."
*   "Generate five compelling bullet points for a website menu description of our [signature dish]. Highlight key ingredients, preparation methods, and the overall dining experience it offers."
*   "Write a short, enticing email subject line and a one-paragraph preview text (under 50 words) for an email announcing our upcoming [special event/tasting menu]. Emphasize exclusivity and the limited-time nature."
*   "Craft a polite and professional response to a customer review that mentions [specific positive aspect] and [specific constructive feedback]. Focus on acknowledging both points and inviting them back."
*   "Create three distinct taglines (under 10 words each) for our [restaurant/cafe] that convey our [unique selling proposition, e.g., farm-to-table, cozy ambiance, innovative cuisine]."
*   "Outline a brief, step-by-step recipe instruction (for a home cook) for our [simple, popular side dish or dessert]. Assume the reader has basic cooking knowledge and common kitchen equipment."
