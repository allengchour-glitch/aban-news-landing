# Proven AI prompts for Friseure

> Copy, replace the brackets, ALWAYS check the result. AI gives you drafts, no guarantees.

1. **Quote / outreach:** "Write a friendly, clear quote for [service] to [client].
   Key points: [...]. Tone: factual, short. No made-up prices — I'll fill those in myself."
2. **Email reply:** "Reply politely and briefly to this message: [paste text]. Goal: [...]."
3. **Review response:** "Write a calm, professional reply to this online review: [text].
   No arguing, solution-oriented, max 4 sentences."
4. **Summarize text:** "Summarize this text in 5 bullet points and list open questions: [text]."
5. **Social post:** "Write a short, honest post (max 80 words) about [topic] for [audience].
   No hype, one concrete tip."
