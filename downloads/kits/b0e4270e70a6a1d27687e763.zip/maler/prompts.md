**Wichtiger Hinweis:** KI-generierte Texte sind Vorschläge. Prüfe die Ergebnisse immer kritisch auf Richtigkeit, Vollständigkeit und Angemessenheit für deine spezifischen Bedürfnisse.

Hier sind 6 erprobte, konkrete KI-Prompts für Maler (DACH):

*   "Ich bin ein Maler und brauche Ideen für Social Media Posts, die meine Expertise in [Spezialisierung, z.B. Fassadenanstrich, Innenraumgestaltung, spezielle Techniken] hervorheben. Gib mir 3 konkrete Post-Ideen, die [Zielgruppe, z.B. Hausbesitzer, Architekten, Bauträger] ansprechen und einen Call-to-Action enthalten."

*   "Schreibe einen kurzen, überzeugenden Text für meine Webseite, der die Vorteile einer Zusammenarbeit mit mir als Maler in [Region/Stadt] beschreibt. Betone dabei [Alleinstellungsmerkmal, z.B. Pünktlichkeit, Sauberkeit, individuelle Beratung, Verwendung nachhaltiger Farben]. Der Text sollte maximal 150 Wörter umfassen."

*   "Ich möchte einen Blogbeitrag über [Thema, z.B. 'Die richtige Farbwahl für kleine Räume', 'So pflegst du deine Fassade richtig', 'Aktuelle Farbtrends 2024'] schreiben. Gib mir 5-7 Stichpunkte für die Gliederung des Beitrags und schlage einen ansprechenden Titel vor."

*   "Formuliere eine professionelle E-Mail-Antwort an einen potenziellen Kunden, der sich nach einem Angebot für [Art des Projekts, z.B. Malerarbeiten im Wohnzimmer, Treppenhausrenovierung] erkundigt hat. Bitte ihn um weitere Details zu [wichtige Informationen, z.B. Größe des Raumes, gewünschter Zeitraum, spezielle Wünsche] und biete einen unverbindlichen Besichtigungstermin an."

*   "Ich suche nach Inspiration für meine nächste Marketingkampagne, die sich an [Zielgruppe, z.B. junge Familien, Senioren, Gewerbekunden] richtet. Gib mir 3 kreative Marketing-Ideen, die mein Malergeschäft in [Region/Stadt] bekannter machen und zu konkreten Anfragen führen könnten. Berücksichtige dabei [Budgetrahmen, z.B. geringes Budget, mittleres Budget]."

*   "Ich brauche Hilfe bei der Formulierung einer kurzen, prägnanten Beschreibung meiner Dienstleistungen für mein Google My Business Profil. Nenne 3-4 Kernleistungen, die ich anbiete, und verwende Keywords, die potenzielle Kunden in [Region/Stadt] bei der Suche nach einem Maler verwenden könnten."
