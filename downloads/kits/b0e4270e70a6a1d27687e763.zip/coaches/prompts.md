Hier sind 6 erprobte, konkrete KI-Prompts für Coaches im DACH-Raum, die du direkt kopieren und anpassen kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen!

* "Du bist ein erfahrener Coach für [Zielgruppe, z.B. Führungskräfte in der Tech-Branche]. Ich möchte einen Blogartikel zum Thema '[Thema, z.B. Work-Life-Balance im Homeoffice]' schreiben. Generiere mir 3-5 überzeugende Überschriften und eine Gliederung mit 5-7 Hauptpunkten, die relevante Aspekte für meine Zielgruppe beleuchten und praktische Tipps enthalten."

* "Ich bereite ein kostenloses Webinar für [Zielgruppe, z.B. Selbstständige im Kreativbereich] vor. Das Thema ist '[Thema, z.B. Preisgestaltung für digitale Produkte]'. Erstelle mir 3-4 Ideen für interaktive Elemente oder Fragen, die ich während des Webinars stellen kann, um das Engagement der Teilnehmer zu fördern und ihre individuellen Herausforderungen zu adressieren."

* "Ich möchte eine E-Mail-Sequenz für neue Newsletter-Abonnenten erstellen. Du bist ein Marketing-Experte für Coaches. Entwirf mir eine 3-teilige Willkommens-Sequenz, die Vertrauen aufbaut, meinen Wert als Coach kommuniziert und einen klaren Call-to-Action für [nächster Schritt, z.B. ein kostenloses Erstgespräch] enthält. Achte auf einen freundlichen, aber professionellen Ton."

* "Ich habe ein Coaching-Programm zum Thema '[Thema, z.B. Stressmanagement für Mütter]' entwickelt. Formuliere mir 3-4 Social-Media-Posts (für [Plattform, z.B. LinkedIn]) die die Vorteile meines Programms hervorheben, auf typische Schmerzpunkte meiner Zielgruppe eingehen und eine Frage stellen, um Interaktion zu fördern. Verwende relevante Emojis."

* "Ich führe ein Einzelcoaching-Gespräch mit einem Klienten, der Schwierigkeiten hat, seine [Problem, z.B. Prokrastination] zu überwinden. Erstelle mir 3-5 offene Fragen, die ich stellen kann, um seine Motivation zu ergründen, seine Blockaden zu identifizieren und ihn dazu zu bringen, eigene Lösungsansätze zu entwickeln. Die Fragen sollen nicht wertend sein."

* "Ich möchte ein kurzes Video für meine Website aufnehmen, in dem ich mich und mein Coaching-Angebot vorstelle. Du bist ein Experte für Storytelling. Schreibe mir ein kurzes Skript (ca. 60-90 Sekunden), das meine [Spezialisierung, z.B. Karriere-Coaching für Quereinsteiger] klar kommuniziert, einen persönlichen Bezug herstellt und die potenziellen Ergebnisse für meine Klienten aufzeigt. Beende das Skript mit einem klaren Call-to-Action."
