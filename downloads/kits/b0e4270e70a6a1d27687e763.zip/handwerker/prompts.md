**Wichtiger Hinweis:** Die Ergebnisse der KI sind Vorschläge und müssen immer kritisch geprüft, angepasst und an die spezifischen Bedürfnisse deines Handwerksbetriebs und deiner Zielgruppe angepasst werden. Sie dienen als Ausgangspunkt, nicht als finale Lösung.

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Handwerker (DACH), in der Du-Form, ehrlich und ohne erfundene Zahlen:

*   "Du bist ein erfahrener Social Media Manager für Handwerksbetriebe. Erstelle 3-5 kurze, ansprechende Instagram-Post-Ideen für [Dein Handwerk, z.B. Dachdecker]. Jeder Post soll einen direkten Mehrwert für Hausbesitzer in [Deine Region, z.B. München] bieten und zum Kommentieren anregen. Verwende Emojis und relevante Hashtags."

*   "Du bist ein Texter, spezialisiert auf die Erstellung von Website-Texten für lokale Handwerker. Schreibe einen überzeugenden 'Über Uns'-Text für meine Website. Mein Betrieb, [Dein Firmenname], ist seit [Anzahl] Jahren in [Deine Stadt/Region] tätig und legt Wert auf [2-3 Kernwerte, z.B. Qualität, Zuverlässigkeit, persönliche Beratung]. Beschreibe kurz, was uns auszeichnet und warum Kunden uns vertrauen sollten."

*   "Entwickle 3-4 E-Mail-Betreffzeilen für einen Newsletter, der sich an potenzielle Kunden richtet, die [spezifisches Problem, das du löst, z.B. undichte Fenster] haben. Die Betreffzeilen sollen Neugier wecken und zum Öffnen der E-Mail anregen, ohne irreführend zu sein. Mein Handwerk ist [Dein Handwerk, z.B. Schreiner]."

*   "Du bist ein Marketingexperte für lokale Dienstleister. Formuliere 2-3 kurze, prägnante Slogans für meinen Handwerksbetrieb, [Dein Firmenname], der sich auf [Deine Spezialisierung, z.B. Badsanierung] konzentriert. Die Slogans sollen unsere Kernkompetenz hervorheben und potenzielle Kunden in [Deine Zielgruppe, z.B. Familien, Senioren] ansprechen."

*   "Stelle dir vor, du bist ein Berater für Kundenservice im Handwerk. Schreibe eine freundliche und professionelle Antwort auf eine negative Online-Bewertung, die besagt: 'Die Arbeiten wurden zwar erledigt, aber die Kommunikation war mangelhaft.' Dein Ziel ist es, Verständnis zu zeigen, eine Lösung anzubieten und den Ruf meines Betriebs, [Dein Firmenname], zu wahren."

*   "Du bist ein Experte für die Erstellung von Angebotstexten im Handwerk. Formuliere eine kurze Einleitung für ein Angebot für [Art der Leistung, z.B. die Neugestaltung eines Gartens]. Die Einleitung soll Vertrauen schaffen, die Wertigkeit unserer Arbeit betonen und den Kunden von unserer Kompetenz überzeugen. Unser Betrieb, [Dein Firmenname], ist bekannt für [1-2 Alleinstellungsmerkmale, z.B. kreative Lösungen, termingerechte Ausführung]."
