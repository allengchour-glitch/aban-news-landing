**Wichtiger Hinweis:** Die Ergebnisse der KI müssen immer sorgfältig geprüft und auf ihre Richtigkeit und Vollständigkeit hin überprüft werden. KI-Modelle können Fehler machen oder unvollständige Informationen liefern.

Hier sind 6 erprobte, konkrete KI-Prompts für Steuerberater (DACH):

*   "Analysiere die neuesten Änderungen im deutschen Einkommensteuergesetz (Stand: [Datum]) bezüglich [spezifisches Thema, z.B. Homeoffice-Pauschale] und fasse die wichtigsten Auswirkungen für [Zielgruppe, z.B. Angestellte mit Remote-Arbeit] in einer prägnanten Übersicht zusammen. Berücksichtige dabei auch potenzielle Fallstricke und Gestaltungsmöglichkeiten."

*   "Erstelle eine Checkliste für die steuerliche Optimierung von [Rechtsform, z.B. GmbH] im Jahr [Steuerjahr]. Die Checkliste soll Punkte wie [Beispiel: Abschreibungen, Rückstellungen, Gewinnausschüttungen] umfassen und konkrete Handlungsempfehlungen für die Mandanten enthalten. Füge auch einen Hinweis auf relevante Fristen hinzu."

*   "Formuliere einen Entwurf für eine E-Mail an Mandanten, die [Problem, z.B. Schwierigkeiten bei der Belegsammlung für die Umsatzsteuererklärung] haben. Die E-Mail soll freundlich, aber bestimmt auf die Notwendigkeit einer vollständigen und fristgerechten Abgabe hinweisen und konkrete Tipps zur Verbesserung der Prozesse geben. Biete auch an, bei Bedarf persönlich zu unterstützen."

*   "Vergleiche die steuerlichen Vorteile und Nachteile einer [Investition A, z.B. Immobilieninvestition] mit einer [Investition B, z.B. Investition in erneuerbare Energien] für einen Mandanten mit einem zu versteuernden Einkommen von [Betrag] Euro und der Rechtsform [Rechtsform, z.B. Einzelunternehmen]. Berücksichtige dabei [spezifische Aspekte, z.B. AfA-Möglichkeiten, Förderprogramme, Risikoaspekte]."

*   "Fasse die wesentlichen Änderungen der [Steuerreform/Gesetzesänderung, z.B. Reform der Erbschaftsteuer] in Österreich (Stand: [Datum]) für [Zielgruppe, z.B. Familienunternehmen] zusammen. Erläutere die Auswirkungen auf die Unternehmensnachfolge und zeige mögliche Gestaltungsoptionen auf, um die Steuerlast zu minimieren."

*   "Erstelle eine Liste der häufigsten Fehler, die Mandanten bei der [Steuererklärung, z.B. Schweizer Mehrwertsteuererklärung] machen, und gib zu jedem Fehler einen kurzen Tipp, wie er vermieden werden kann. Die Liste soll praxisnah sein und sich auf typische Fälle konzentrieren, die du in deiner Kanzlei beobachtet hast."
