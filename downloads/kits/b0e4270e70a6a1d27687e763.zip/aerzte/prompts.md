**Wichtiger Hinweis: Die Ergebnisse der KI müssen immer kritisch geprüft und von einem Arzt verifiziert werden, bevor sie in der Praxis angewendet werden!**

Hier sind 6 erprobte, konkrete KI-Prompts zum Kopieren für Ärzte (DACH):

* "Erstelle eine Zusammenfassung der aktuellen Leitlinien (z.B. der AWMF) für die Diagnose und Therapie von [Krankheit, z.B. Typ-2-Diabetes] bei erwachsenen Patienten. Berücksichtige dabei insbesondere die Empfehlungen zur [spezifischer Aspekt, z.B. medikamentösen Therapie und Lebensstilinterventionen]."
* "Ich habe einen Patienten mit [Symptom A, z.B. anhaltendem Husten] und [Symptom B, z.B. Gewichtsverlust]. Welche Differenzialdiagnosen sollten in Betracht gezogen werden und welche diagnostischen Schritte (z.B. Labor, Bildgebung) sind in dieser Situation typischerweise indiziert?"
* "Formuliere einen verständlichen Patienteninformationsbogen über [Behandlungsmethode, z.B. eine bevorstehende Koloskopie]. Erkläre die Prozedur, mögliche Risiken, Vorteile und die Vorbereitung in einfachen Worten, ohne medizinischen Fachjargon."
* "Analysiere diesen aktuellen wissenschaftlichen Artikel (DOI: [DOI des Artikels]) und fasse die wichtigsten Studienergebnisse, die Methodik und die klinische Relevanz prägnant zusammen. Gehe dabei insbesondere auf die [spezifische Fragestellung, z.B. Wirksamkeit eines neuen Medikaments] ein."
* "Ich möchte einen Vortrag für Kollegen über [Thema, z.B. neue Entwicklungen in der Onkologie] vorbereiten. Gib mir eine Gliederung mit den wichtigsten Unterpunkten und schlage relevante Schlüsselbegriffe vor, die ich in meiner Recherche berücksichtigen sollte."
* "Ein Patient fragt mich nach den Vor- und Nachteilen von [Alternative A, z.B. einer medikamentösen Therapie] im Vergleich zu [Alternative B, z.B. einer chirurgischen Intervention] bei [Krankheit, z.B. einer Bandscheibenprotrusion]. Erstelle eine Liste der wichtigsten Argumente für beide Optionen, die ich mit dem Patienten besprechen kann."
