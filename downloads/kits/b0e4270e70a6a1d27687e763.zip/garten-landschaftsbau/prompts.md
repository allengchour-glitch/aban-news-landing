Hier sind 6 erprobte KI-Prompts für den Garten- und Landschaftsbau (DACH), die du direkt kopieren und anpassen kannst. Denke daran, die Ergebnisse immer kritisch zu prüfen und an deine spezifischen Bedürfnisse anzupassen.

---

**Hinweis:** Die Ergebnisse der KI müssen stets auf Richtigkeit, Relevanz und Aktualität überprüft und gegebenenfalls angepasst werden.

---

1.  "Erstelle mir eine Liste von 5 innovativen, pflegeleichten Gestaltungsideen für einen modernen Vorgarten in [Region/Klimazone, z.B. Süddeutschland, gemäßigtes Klima]. Berücksichtige dabei Aspekte wie Biodiversität, Wassereffizienz und Ästhetik. Nenne konkrete Pflanzenbeispiele und Materialien."

2.  "Schreibe einen Entwurf für einen Blogbeitrag mit dem Titel 'Dein Traumgarten: So planst du dein Gartenprojekt erfolgreich in [Jahreszeit, z.B. Frühling]'. Gehe auf die wichtigsten Schritte von der Ideenfindung über die Budgetplanung bis zur Materialauswahl ein. Verwende eine ansprechende und motivierende Sprache."

3.  "Ich benötige 3 Social Media Posts (Instagram & Facebook) für unser Unternehmen [Firmenname] zum Thema 'Nachhaltige Gartengestaltung'. Jeder Post sollte einen Call-to-Action enthalten, wie z.B. 'Kontaktiere uns für eine Beratung' oder 'Besuche unsere Website'. Verwende relevante Hashtags für den DACH-Raum."

4.  "Formuliere eine E-Mail-Vorlage für die Nachfassaktion nach einem Erstgespräch mit einem potenziellen Kunden für eine Gartenneugestaltung. Die E-Mail sollte freundlich, professionell und überzeugend sein und die nächsten Schritte klar aufzeigen. Füge einen Platzhalter für das individuelle Angebot ein."

5.  "Gib mir 4 Argumente, warum sich die Investition in eine professionelle Gartenpflege durch [Firmenname] langfristig lohnt. Fokussiere dich auf Zeitersparnis, Werterhalt der Immobilie, Fachwissen und die Gewährleistung eines gesunden Pflanzenwachstums. Vermeide dabei übertriebene Marketingfloskeln."

6.  "Entwickle eine Checkliste für die Erstberatung mit einem Kunden, der seinen [Gartentyp, z.B. Reihenhausgarten] umgestalten möchte. Die Checkliste sollte Fragen zu seinen Wünschen, seinem Budget, seiner Nutzungsabsicht, dem Pflegeaufwand und den vorhandenen Gegebenheiten (Boden, Licht) enthalten."
