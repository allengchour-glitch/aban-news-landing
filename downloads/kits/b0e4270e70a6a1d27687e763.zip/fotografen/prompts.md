Absolut! Hier sind 6 erprobte, konkrete KI-Prompts für Fotografen im DACH-Raum, die du direkt kopieren und anpassen kannst. Denk daran, die Ergebnisse immer kritisch zu prüfen und gegebenenfalls manuell zu optimieren. KI ist ein Werkzeug, kein Ersatz für dein Fachwissen.

---

*Erinnerung: Die Ergebnisse der KI sind Vorschläge und müssen immer auf Richtigkeit, Tonalität und Passgenauigkeit geprüft und gegebenenfalls manuell angepasst werden.*

---

*   "Ich brauche 5 Social Media Post-Ideen für [Plattform, z.B. Instagram], um meine neuen [Art der Fotografie, z.B. Hochzeitsfotos] zu bewerben. Der Fokus soll auf [Emotion/Nutzen für Kunden, z.B. die unvergesslichen Momente festhalten] liegen. Nutze eine lockere, persönliche Ansprache und integriere einen Call-to-Action, der auf [Ziel, z.B. meine Website für ein unverbindliches Angebot] verweist."

*   "Erstelle einen Entwurf für eine E-Mail an potenzielle Kunden, die sich für [Art der Fotografie, z.B. Familienporträts] interessieren. Die E-Mail soll meine Expertise hervorheben, den Ablauf kurz erklären und einen Mehrwert bieten, z.B. [Mehrwert, z.B. einen Link zu einem Blogbeitrag über die Vorbereitung auf ein Shooting]. Die Sprache soll professionell, aber warmherzig sein."

*   "Formuliere 3 verschiedene Bildunterschriften für ein Foto von [Beschreibung des Fotos, z.B. einem Paar im Sonnenuntergang]. Eine soll romantisch sein, eine humorvoll und eine, die den Fokus auf die Technik oder den Ort legt. Verwende relevante Hashtags für [Zielgruppe/Thema, z.B. #Hochzeitsfotograf #Paarshooting #Liebe]."

*   "Ich benötige Stichpunkte für einen Blogbeitrag zum Thema '[Thema, z.B. 5 Tipps für authentische Businessporträts]'. Der Beitrag soll [Zielgruppe, z.B. Selbstständige und kleine Unternehmen] ansprechen und meine Kompetenz in diesem Bereich unterstreichen. Integriere Ideen für [Call-to-Action, z.B. ein kostenloses Erstgespräch]."

*   "Schreibe einen kurzen Text für meine 'Über mich'-Seite auf meiner Website. Ich bin [Dein Name], spezialisiert auf [Deine Nische, z.B. emotionale Reportagefotografie]. Betone meine Leidenschaft für [Aspekt der Fotografie, z.B. das Erzählen von Geschichten durch Bilder] und meinen Ansatz, der [Dein Alleinstellungsmerkmal, z.B. natürliche und ungestellte Momente] einfängt. Die Tonalität soll persönlich und vertrauenswürdig sein."

*   "Generiere 4 Fragen, die ich meinen Kunden vor einem Shooting stellen kann, um ihre Erwartungen besser zu verstehen und das Shooting optimal vorzubereiten. Die Fragen sollen sich auf [Aspekt, z.B. ihre Vision, gewünschte Stimmung und Nutzung der Bilder] konzentrieren und mir helfen, ihre Persönlichkeit einzufangen."
