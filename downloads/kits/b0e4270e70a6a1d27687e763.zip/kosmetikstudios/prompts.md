Gerne, hier sind 6 erprobte, konkrete KI-Prompts für Kosmetikstudios (DACH) in der Du-Form, ehrlich und ohne erfundene Zahlen. Bitte beachte, dass die Ergebnisse der KI immer geprüft und gegebenenfalls angepasst werden müssen, um die Qualität und Genauigkeit zu gewährleisten.

---

*   "Du möchtest wissen, wie Du Deine Haut optimal auf die [Jahreszeit, z.B. Sommer] vorbereitest? Wir verraten Dir in [Anzahl] einfachen Schritten, welche Pflege jetzt besonders wichtig ist und welche Behandlungen in unserem Studio Dir dabei helfen, einen strahlenden Teint zu bekommen. Entdecke unsere Tipps für eine gesunde und schöne Haut!"

*   "Fühlst Du Dich manchmal überfordert von der Vielzahl an Hautpflegeprodukten? Wir helfen Dir, den Überblick zu behalten! Beschreibe uns Dein aktuelles Hautproblem (z.B. trockene Haut, Unreinheiten, erste Fältchen) und wir empfehlen Dir [Anzahl] konkrete Produkte oder Behandlungen aus unserem Angebot, die wirklich zu Dir passen. Keine leeren Versprechungen, sondern individuelle Lösungen."

*   "Du suchst nach einer Auszeit vom Alltag und möchtest Deiner Haut etwas Gutes tun? Erfahre, welche unserer [Anzahl] beliebtesten Gesichtsbehandlungen am besten zu Deinen Bedürfnissen passt. Von der tiefenreinigenden Behandlung bis zur entspannenden Anti-Aging-Massage – wir haben das Richtige für Dich. Buche noch heute Deinen Verwöhnmoment!"

*   "Du hast Fragen zu [spezifisches Thema, z.B. Microneedling, Wimpernlifting, Permanent Make-up]? Wir beantworten die [Anzahl] häufigsten Fragen zu dieser Behandlung. Erfahre, wie sie abläuft, welche Ergebnisse Du erwarten kannst und ob sie für Dich geeignet ist. Transparenz ist uns wichtig, damit Du eine fundierte Entscheidung treffen kannst."

*   "Du möchtest Deine Hautpflegeroutine optimieren, weißt aber nicht, wo Du anfangen sollst? Wir bieten Dir eine kostenlose [Dauer, z.B. 15-minütige] Online-Hautanalyse an. Sende uns ein Foto Deiner Haut und beantworte ein paar Fragen, und wir geben Dir erste, unverbindliche Empfehlungen für Deine individuelle Pflege. Entdecke Dein Potenzial für eine gesunde Haut!"

*   "Du bist neugierig auf die neuesten Trends in der Kosmetikbranche? Wir stellen Dir [Anzahl] aktuelle Innovationen vor, die wir in unserem Studio anbieten oder demnächst einführen werden. Erfahre, welche neuen Technologien und Wirkstoffe Deine Hautpflegeroutine revolutionieren können. Bleib auf dem Laufenden und sei eine der Ersten, die davon profitieren!"
