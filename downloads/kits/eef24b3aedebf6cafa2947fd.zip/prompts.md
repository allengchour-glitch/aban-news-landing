**Wichtiger Hinweis:** Die Ergebnisse der KI sind stets kritisch zu prüfen und dürfen nicht ungeprüft übernommen werden. Sie dienen als Unterstützung und Ideengeber, ersetzen aber nicht die fachliche Expertise und Sorgfaltspflicht des Steuerberaters.

Hier sind 6 erprobte, konkrete KI-Prompts für Steuerberater (DACH):

*   "Analysiere die steuerlichen Auswirkungen der Gründung einer [Rechtsform, z.B. GmbH] in [Bundesland/Kanton] für einen Mandanten, der [Art des Geschäfts, z.B. Softwareentwicklung] betreiben möchte. Berücksichtige dabei die [Anzahl] voraussichtlichen Mitarbeiter und ein geschätztes Jahresumsatzvolumen von [Betrag in Euro/CHF]. Welche steuerlichen Vorteile und Nachteile ergeben sich im Vergleich zu einem Einzelunternehmen und welche Gestaltungsmöglichkeiten zur Steueroptimierung siehst du?"

*   "Erstelle einen Entwurf für eine E-Mail an einen Mandanten, der nach der Einführung des [neues Gesetz/Verordnung, z.B. Wachstumschancengesetzes] fragt. Erkläre kurz und verständlich die wesentlichen Änderungen für [Zielgruppe des Mandanten, z.B. kleine und mittlere Unternehmen] und biete ein persönliches Beratungsgespräch an, um die individuellen Auswirkungen zu besprechen."

*   "Fasse die aktuellen Urteile des [Gericht, z.B. Bundesfinanzhofs] zum Thema [Steuerrechtliches Thema, z.B. häusliches Arbeitszimmer] der letzten [Zeitraum, z.B. 12 Monate] zusammen. Identifiziere dabei die wichtigsten Präzedenzfälle und deren potenzielle Auswirkungen auf die Steuererklärungen unserer Mandanten. Gib konkrete Handlungsempfehlungen, welche Informationen wir von Mandanten in diesem Kontext abfragen sollten."

*   "Entwickle eine Checkliste für die Jahresabschlusserstellung eines [Branche, z.B. Handwerksbetriebs] mit [Anzahl] Mitarbeitern. Berücksichtige dabei typische Besonderheiten dieser Branche in Bezug auf [spezifisches Thema, z.B. Anlagevermögen, Warenbewertung, Rückstellungen] und füge Hinweise zu relevanten Dokumenten und Fristen hinzu. Welche spezifischen Fragen sollten wir dem Mandanten vorab stellen?"

*   "Formuliere eine kurze, prägnante Erklärung für einen Mandanten, warum die [Steuerart, z.B. Umsatzsteuer-Voranmeldung] trotz geringer Umsätze fristgerecht abgegeben werden muss. Erkläre die Konsequenzen einer Nichtabgabe und biete an, den Prozess für ihn zu übernehmen. Verwende eine verständliche Sprache ohne Fachjargon."

*   "Recherchiere die aktuellen Fördermöglichkeiten und Zuschüsse auf [Ebene, z.B. Bundes-, Landes- oder Kantonsebene] für Unternehmen, die in [Bereich, z.B. Digitalisierung, Energieeffizienz] investieren möchten. Erstelle eine Liste der relevantesten Programme für [Zielgruppe, z.B. Start-ups, KMU] und gib an, welche Voraussetzungen erfüllt sein müssen und wo weitere Informationen zu finden sind."
