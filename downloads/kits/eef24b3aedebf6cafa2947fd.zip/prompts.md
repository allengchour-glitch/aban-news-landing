**Wichtiger Hinweis:** Die Ergebnisse der KI müssen stets von einem qualifizierten Steuerberater geprüft und verifiziert werden. KI-Tools sind Hilfsmittel und ersetzen keine professionelle Beratung.

Hier sind 6 erprobte, konkrete KI-Prompts für Steuerberater (DACH):

*   "Analysiere die steuerlichen Auswirkungen der Gründung eines [Rechtsform, z.B. GmbH] in [Bundesland/Kanton] für einen Mandanten, der ein jährliches Bruttoeinkommen von [Betrag] €/CHF und geplante Investitionen von [Betrag] €/CHF erwartet. Berücksichtige dabei die Körperschaftsteuer, Gewerbesteuer/Kantonssteuer und die Besteuerung von Gewinnausschüttungen. Nenne die wesentlichen Vor- und Nachteile dieser Rechtsform aus steuerlicher Sicht im Vergleich zu einem Einzelunternehmen."

*   "Erstelle eine Checkliste für die steuerliche Optimierung eines Immobilienverkaufs in [Land, z.B. Deutschland] für einen privaten Mandanten, der eine Immobilie nach [Anzahl] Jahren Haltedauer verkauft. Die Anschaffungskosten betrugen [Betrag] € und der Verkaufspreis liegt bei [Betrag] €. Berücksichtige dabei die Spekulationsfrist, mögliche Abzugsfähigkeiten und die Berechnung des zu versteuernden Gewinns. Welche Dokumente sind dafür relevant?"

*   "Formuliere einen Entwurf für eine E-Mail an einen Mandanten, der wissen möchte, welche Belege er für die Geltendmachung von Homeoffice-Kosten im Steuerjahr [Jahr] benötigt. Erkläre kurz und prägnant die Voraussetzungen für die Homeoffice-Pauschale und die Absetzbarkeit eines häuslichen Arbeitszimmers. Bitte um Zusendung relevanter Unterlagen."

*   "Vergleiche die steuerlichen Vorteile einer betrieblichen Altersvorsorge (bAV) über eine Direktversicherung mit denen einer privaten Rentenversicherung für einen Angestellten mit einem Bruttojahresgehalt von [Betrag] €/CHF. Gehe auf die Besteuerung in der Anspar- und Auszahlungsphase ein und nenne die wesentlichen Unterschiede in Bezug auf Sozialabgaben und Förderungen."

*   "Erstelle eine Liste der wichtigsten Änderungen im Steuerrecht für das Jahr [Jahr] in [Land, z.B. Österreich], die für kleine und mittlere Unternehmen (KMU) relevant sind. Fasse die Kernpunkte kurz zusammen und gib an, welche Auswirkungen diese auf die Buchhaltung und Steuererklärung haben könnten. Nenne auch die Quellen für weitere Informationen."

*   "Analysiere die steuerliche Behandlung von Kryptowährungen (z.B. Bitcoin, Ethereum) in [Land, z.B. Schweiz] für einen privaten Anleger. Erläutere die Haltedauerregelungen, die Besteuerung von Gewinnen aus Verkäufen und das Staking. Welche Dokumentation ist für die Steuererklärung erforderlich und welche Risiken bestehen aus steuerlicher Sicht?"
