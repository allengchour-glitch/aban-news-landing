**Wichtiger Hinweis:** Die Ergebnisse der KI müssen stets kritisch geprüft und mit den aktuellen Gesetzen und Vorschriften abgeglichen werden. KI-Modelle können Fehler machen oder veraltete Informationen verwenden.

Hier sind 6 erprobte, konkrete KI-Prompts für Steuerberater (DACH):

*   "Analysiere die steuerlichen Auswirkungen von [geplanter Investition/Transaktion] für meinen Mandanten [Name des Mandanten/Unternehmens] unter Berücksichtigung der aktuellen Gesetzeslage in [Land, z.B. Deutschland]. Berücksichtige dabei insbesondere [spezifische Steuerarten, z.B. Körperschaftsteuer, Umsatzsteuer, Grunderwerbsteuer] und gib eine Einschätzung der Risiken und Chancen ab. Formuliere Empfehlungen für eine steueroptimale Gestaltung."

*   "Erstelle einen Entwurf für eine E-Mail an meinen Mandanten [Name des Mandanten/Unternehmens], in der ich die Änderungen im [Steuergesetz/Verordnung, z.B. Jahressteuergesetz 2024] bezüglich [spezifisches Thema, z.B. Homeoffice-Pauschale, Abschreibungsmöglichkeiten] zusammenfasse. Erkläre die relevantesten Punkte verständlich und nenne konkrete Handlungsempfehlungen, die der Mandant beachten sollte."

*   "Vergleiche die steuerlichen Vor- und Nachteile der Rechtsformen [Rechtsform 1, z.B. GmbH] und [Rechtsform 2, z.B. Einzelunternehmen] für einen Mandanten, der ein [Branche, z.B. IT-Beratungsunternehmen] mit einem erwarteten Jahresgewinn von [Betrag, z.B. 150.000 EUR] gründen möchte. Berücksichtige dabei Aspekte wie Haftung, Besteuerung des Gewinns und der Entnahmen sowie den Verwaltungsaufwand."

*   "Fasse die wichtigsten Neuerungen im Bereich der [Steuerart, z.B. Umsatzsteuer] für das kommende Geschäftsjahr [Jahr, z.B. 2025] zusammen, die für Unternehmen in [Branche, z.B. Onlinehandel] relevant sind. Gib konkrete Beispiele, wie sich diese Änderungen auf die tägliche Arbeit auswirken könnten und welche Anpassungen in der Buchhaltung oder bei Prozessen notwendig sein könnten."

*   "Formuliere eine Antwort auf eine Anfrage des Finanzamtes bezüglich [spezifischer Sachverhalt, z.B. Belegprüfung für Reisekosten] für meinen Mandanten [Name des Mandanten/Unternehmens]. Stelle die Fakten klar dar, verweise auf die relevanten Belege und Gesetzesgrundlagen und argumentiere für die steuerliche Anerkennung der geltend gemachten Aufwendungen. Achte auf einen professionellen und rechtssicheren Ton."

*   "Erstelle eine Checkliste für die Jahresabschlusserstellung für einen [Art des Unternehmens, z.B. mittelständischen Handwerksbetrieb]. Die Checkliste soll alle relevanten Schritte von der Datenaufbereitung bis zur Einreichung beim Finanzamt umfassen und spezifische Punkte für [besondere Aspekte, z.B. Inventur, Rückstellungen, Anlagevermögen] beinhalten. Füge auch Hinweise zu Fristen und möglichen Fallstricken hinzu."
