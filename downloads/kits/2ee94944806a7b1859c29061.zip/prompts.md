**Important Note:** Always review the AI-generated content for accuracy, tone, and brand consistency before using it. AI is a tool, not a replacement for human oversight.

Here are 6 proven, concrete copy-paste AI prompts for Kosmetikstudios:

*   "Schreibe 3 Social Media Posts (Instagram, Facebook) für [Name des Kosmetikstudios], die unsere neue Behandlung '[Name der Behandlung]' bewerben. Fokus auf die Vorteile für den Kunden wie '[Vorteil 1]', '[Vorteil 2]' und '[Vorteil 3]'. Verwende Emojis und einen Call-to-Action, um einen Termin zu vereinbaren. Hashtags: #[NameDerBehandlung] #[KosmetikstudioName] #[Stadt]."

*   "Formuliere eine kurze E-Mail an unsere bestehenden Kunden, um sie über unsere bevorstehende '[Saisonale Aktion/Angebot]' zu informieren. Betone den Wert '[Wert des Angebots]' und die begrenzte Verfügbarkeit bis zum [Datum]. Füge einen Link zur Online-Buchung hinzu: [Link zur Buchung]."

*   "Erstelle 5 kurze, ansprechende Überschriften für eine Landing Page, die unsere '[Dienstleistung]' bewirbt. Die Überschriften sollen Neugier wecken und den Hauptnutzen hervorheben, z.B. 'Strahlende Haut in [Zeitraum]' oder 'Verabschiede dich von [Problem]'. Zielgruppe: [Altersgruppe], die [Hautproblem] haben."

*   "Schreibe einen kurzen Text für unsere 'Über uns'-Seite auf der Website. Beschreibe die Philosophie von [Name des Kosmetikstudios], unsere Werte wie '[Wert 1]' und '[Wert 2]', und was uns von anderen Studios unterscheidet. Erwähne kurz die Expertise unseres Teams und die persönliche Betreuung, die wir bieten."

*   "Entwickle 3 Fragen, die wir unseren Kunden nach einer Behandlung stellen können, um ehrliches Feedback zu erhalten. Die Fragen sollen sich auf die Zufriedenheit mit der Behandlung, dem Ambiente und dem Service konzentrieren. Beispiel: 'Was hat Ihnen an der Behandlung am besten gefallen?'"

*   "Verfasse eine kurze Antwort auf eine 4-Sterne-Bewertung auf Google, die besagt: 'Die Behandlung war super, aber die Wartezeit war etwas lang.' Bedanke dich für das positive Feedback zur Behandlung und entschuldige dich höflich für die Wartezeit. Versichere, dass wir daran arbeiten, unsere Abläufe zu optimieren."
