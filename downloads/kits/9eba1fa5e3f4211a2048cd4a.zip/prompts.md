**Always review and refine AI-generated content for accuracy, brand voice, and suitability before use.**

Here are 6 proven, concrete copy-paste AI prompts for a Goldschmiede:

*   "Generate 5 unique, evocative Instagram captions for a new collection of [type of jewelry, e.g., emerald engagement rings]. Focus on craftsmanship, emotional connection, and the brilliance of the gemstones. Include relevant emojis and 2-3 hashtags per caption. Our target audience appreciates timeless elegance and quality."

*   "Write a concise, compelling product description (max 150 words) for our [specific item, e.g., handcrafted 18k gold necklace with a single brilliant-cut diamond]. Highlight its unique design features, the quality of materials, and the feeling it evokes. Emphasize its suitability for [occasion, e.g., a milestone anniversary gift]. Include a call to action to visit our store or website."

*   "Draft a personalized email subject line and opening paragraph for a customer who recently purchased a [type of jewelry, e.g., custom-designed wedding band] from us. The email should express gratitude, invite them to share their experience, and subtly introduce our [related service, e.g., complimentary cleaning and inspection]. Keep it warm and professional."

*   "Create 3 distinct headline options for a blog post about 'The [Number, e.g., 4] Essential Questions to Ask Before Buying a Diamond.' The headlines should be engaging, informative, and appeal to customers seeking knowledge and reassurance. Avoid jargon where possible."

*   "Develop a short, persuasive script (max 100 words) for a social media video promoting our [service, e.g., bespoke jewelry design service]. The script should highlight the collaborative process, the unique outcome, and the emotional value of a custom piece. End with a clear call to action to book a consultation."

*   "Generate 4 bullet points outlining the benefits of choosing a handcrafted piece of jewelry from a local goldsmith compared to mass-produced alternatives. Focus on aspects like unique design, quality of materials, ethical sourcing, and personalized service. These will be used on our 'About Us' page."
