**Important Note:** AI-generated content should always be reviewed and edited by a qualified legal professional to ensure accuracy, compliance, and suitability for the specific case. These prompts are designed to assist, not replace, human legal expertise.

* "Draft a cease and desist letter regarding [infringement type, e.g., copyright infringement, trademark misuse] of [your client's intellectual property, e.g., 'the 'LegalEagle' logo and branding'] by [offending party's name] located at [offending party's address]. Include demands for [specific actions, e.g., 'immediate cessation of use, removal of infringing materials from all platforms, and an accounting of profits']. Set a response deadline of [date]."

* "Summarize the key legal arguments presented in the attached [document type, e.g., 'plaintiff's motion for summary judgment'] concerning [case topic, e.g., 'a breach of contract dispute over software development']. Identify the most salient points for and against our client, [client's name]."

* "Generate a list of potential discovery requests (interrogatories and requests for production of documents) for a personal injury case involving a [type of accident, e.g., 'car accident'] where our client, [client's name], sustained [type of injuries, e.g., 'whiplash and a fractured arm']. Focus on obtaining information regarding [specific areas, e.g., 'the defendant's insurance coverage, their driving history, and the vehicle's maintenance records']."

* "Explain the legal implications of [specific legal concept, e.g., 'force majeure clauses'] in the context of a [type of contract, e.g., 'commercial lease agreement'] for a client who is [client's situation, e.g., 'unable to pay rent due to a natural disaster']. Provide examples of how such clauses are typically interpreted by courts in [relevant jurisdiction, e.g., 'German law']."

* "Draft a client intake form for a new client seeking advice on [area of law, e.g., 'family law matters, specifically divorce and child custody']. Include sections for personal details, marital history, children's information, financial assets and liabilities, and a brief description of their current concerns and desired outcomes."

* "Analyze the attached [legal document, e.g., 'court judgment'] from the [court name, e.g., 'Regional Court of Munich'] in case number [case number]. Identify the court's reasoning for its decision, the legal precedents cited, and the potential implications for our client, [client's name], who is considering an appeal."
