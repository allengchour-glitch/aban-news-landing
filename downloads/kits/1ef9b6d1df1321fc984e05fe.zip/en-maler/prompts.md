**Note: AI-generated results must always be reviewed and edited for accuracy, tone, and brand consistency.**

*   "Generate 5 distinct, engaging social media post captions for a new [product/service name] launch. Focus on [key benefit 1] and [key benefit 2]. Include a clear call to action: [CTA text]."
*   "Write a 300-word blog post introduction for an article titled '[Blog Post Title]'. The target audience is [target audience description], and the goal is to [inform/persuade/entertain] them about [main topic]."
*   "Draft three email subject lines for an abandoned cart recovery email. The product is [product name], and the offer is [discount/free shipping/etc.]. Aim for a sense of urgency and value."
*   "Create 10 unique headline options for a landing page promoting [product/service name]. Focus on [specific pain point] and how our solution provides [specific solution]."
*   "Generate a short, compelling paragraph (approx. 75 words) describing the unique selling proposition of [company name]. Highlight [key differentiator 1] and [key differentiator 2] for [target audience]."
*   "Write 5 variations of a Google Ads headline (30 characters max) and 3 variations of a description line (90 characters max) for the keyword '[specific keyword]'. Focus on driving clicks to a page about [product/service benefit]."
