**Always review AI-generated content for accuracy, tone, and brand consistency before use.**

*   "Erstelle 5 Social Media Posts für [Plattform, z.B. Instagram], die unsere neue [Dienstleistung, z.B. Balayage-Technik] bewerben. Jeder Post soll einen Call-to-Action enthalten, um einen Termin zu buchen. Verwende Emojis und relevante Hashtags."
*   "Schreibe eine E-Mail an unsere bestehenden Kunden, um sie über unsere [Sonderaktion/Rabatt, z.B. '20% auf alle Haarpflegeprodukte im Juli'] zu informieren. Die E-Mail sollte persönlich klingen und einen Link zur Online-Terminbuchung enthalten."
*   "Formuliere 3 verschiedene Überschriften für einen Blogbeitrag über 'Die besten Tipps für gesundes Haar im Sommer'. Die Überschriften sollen neugierig machen und zum Klicken anregen."
*   "Entwickle 4 kurze Texte für Google My Business Posts, die auf unsere [spezifische Expertise, z.B. 'Expertise in Hochzeitsfrisuren'] hinweisen und Kunden dazu ermutigen, uns zu besuchen. Füge relevante Keywords hinzu."
*   "Erstelle einen Skriptentwurf für ein kurzes Video (ca. 30 Sekunden) für [Plattform, z.B. TikTok], das den Prozess einer [Dienstleistung, z.B. 'kompletten Farbveränderung'] zeigt. Das Skript sollte eine kurze Einführung, die wichtigsten Schritte und einen Call-to-Action beinhalten."
*   "Schreibe eine freundliche, aber professionelle Antwort auf eine [positive/negative] Kundenbewertung auf [Plattform, z.B. Google]. Die Antwort sollte [spezifische Punkte der Bewertung aufgreifen, z.B. 'sich für das Lob bedanken' oder 'Lösungsansatz für das Problem anbieten']."
