**Always review AI-generated content for accuracy, tone, and brand consistency before use.**

*   "Erstelle eine Vorlage für eine professionelle E-Mail zur Kundenanfrage für [Produkt/Dienstleistung]. Die E-Mail sollte folgende Punkte enthalten: [Begrüßung], [kurze Vorstellung des Anliegens], [spezifische Fragen oder Informationen, die benötigt werden], [Angebot zur weiteren Unterstützung], [freundlicher Abschluss]."

*   "Generiere eine Vorlage für einen Social-Media-Post (LinkedIn) zur Ankündigung unseres neuen [Features/Produkts]. Der Post sollte [Zielgruppe] ansprechen, die [Hauptvorteile] hervorheben und einen klaren Call-to-Action zu [Link] enthalten. Verwende einen professionellen und engagierten Ton."

*   "Schreibe eine Vorlage für eine interne Meeting-Agenda für ein [Team-Meeting] zum Thema [Thema des Meetings]. Die Agenda sollte folgende Punkte umfassen: [Datum, Uhrzeit, Ort], [Teilnehmer], [Ziel des Meetings], [Diskussionspunkte mit Zeitrahmen], [Aktionspunkte], [Nächste Schritte]."

*   "Entwickle eine Vorlage für eine Stellenbeschreibung für die Position [Jobtitel]. Die Beschreibung sollte [Hauptaufgaben], [erforderliche Qualifikationen], [gewünschte Fähigkeiten], [Vorteile der Position/des Unternehmens] und Informationen zur Bewerbung enthalten. Verwende eine ansprechende und präzise Sprache."

*   "Erstelle eine Vorlage für eine Dankes-E-Mail nach einem Vorstellungsgespräch für die Position [Jobtitel]. Die E-Mail sollte [Dank für die Zeit], [Bezugnahme auf einen spezifischen Punkt des Gesprächs], [Bekräftigung des Interesses] und [freundlichen Abschluss] enthalten."

*   "Generiere eine Vorlage für eine kurze Pressemitteilung zur Veröffentlichung von [Ereignis/Produkt/Studie]. Die Pressemitteilung sollte [Datum], [Ort], [Überschrift], [Einleitung mit den wichtigsten Informationen], [Hauptteil mit Details und Zitaten von [Name/Titel]], [Call-to-Action/Weitere Informationen] und [Kontaktinformationen für Medienanfragen] umfassen."
