**Always review AI-generated content for accuracy and brand consistency before use.**

* "Generate 5 unique, engaging Instagram caption ideas for a recent [type of photography] photoshoot featuring [key subject/theme]. Focus on evoking [desired emotion] and include relevant emojis. Use a [tone] voice."
* "Write a concise, compelling email subject line and a 3-sentence body for a newsletter announcing my new [type of photography] package. Highlight the benefit of [specific benefit] and include a call to action to 'Learn More' linking to [your website URL]."
* "Create 3 distinct blog post titles and a 2-sentence introductory paragraph for a post about 'The Importance of [Specific Photography Niche] for [Target Audience]'. The tone should be [informative/inspirational/educational]."
* "Develop 4 creative ideas for a Facebook ad campaign targeting [demographic] interested in [type of photography]. Each idea should include a headline, a brief description of the visual, and a call to action. Focus on solving the problem of [client pain point]."
* "Draft 2 variations of a short, impactful testimonial request email to a satisfied client from their recent [type of photography] session. Emphasize how their feedback helps other potential clients and offer a small incentive like [discount/feature on social media]."
* "Generate 6 keyword ideas for SEO optimization for a portfolio page showcasing [type of photography] in [your city/region]. Include both long-tail and short-tail keywords that potential clients might use to find my services."
